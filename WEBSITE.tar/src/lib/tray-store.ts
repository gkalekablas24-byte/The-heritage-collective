"use client";

import { create } from "zustand";
import { dishes, parsePrice, formatPrice } from "@/lib/dishes";

export interface TrayLine {
  id: string;
  qty: number;
}

interface TrayState {
  lines: Record<string, TrayLine>;
  isOpen: boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  dec: (id: string) => void;
  clear: () => void;
  open: () => void;
  close: () => void;
  toggle: () => void;
}

export const useTray = create<TrayState>((set) => ({
  lines: {},
  isOpen: false,
  add: (id) =>
    set((s) => {
      const line = s.lines[id];
      return {
        lines: {
          ...s.lines,
          [id]: { id, qty: (line?.qty ?? 0) + 1 },
        },
      };
    }),
  remove: (id) =>
    set((s) => {
      const next = { ...s.lines };
      delete next[id];
      return { lines: next };
    }),
  dec: (id) =>
    set((s) => {
      const line = s.lines[id];
      if (!line) return s;
      const q = line.qty - 1;
      const next = { ...s.lines };
      if (q <= 0) delete next[id];
      else next[id] = { id, qty: q };
      return { lines: next };
    }),
  clear: () => set({ lines: {} }),
  open: () => set({ isOpen: true }),
  close: () => set({ isOpen: false }),
  toggle: () => set((s) => ({ isOpen: !s.isOpen })),
}));

export { formatPrice, parsePrice };

/* ------------------------------------------------------------------ */
/*  Stable selectors — module-level so selector identity is preserved   */
/*  across renders (avoids re-subscriptions in useSyncExternalStore).   */
/* ------------------------------------------------------------------ */
export const selectLines = (s: TrayState) => s.lines;
export const selectIsOpen = (s: TrayState) => s.isOpen;
export const selectOpen = (s: TrayState) => s.open;
export const selectClose = (s: TrayState) => s.close;
export const selectAdd = (s: TrayState) => s.add;
export const selectDec = (s: TrayState) => s.dec;
export const selectRemove = (s: TrayState) => s.remove;
