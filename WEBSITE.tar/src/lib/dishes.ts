// Dish data — Sakura Sushi Bar
// Each dish carries a food story, ingredient list, chef's note and dietary tags.
// Dietary tags reference the "Japan, Your Way" theme: vegetarian, vegan, jain-friendly.

export type DietTag = "vegetarian" | "vegan" | "jain-friendly" | "omnivore";

export interface HiddenIngredient {
  name: string;       // e.g. "Bonito flakes (katsuo-bushi)"
  risk: "high" | "medium" | "low"; // chance the dish normally contains it
  note: string;       // why it matters / what to ask
}

export interface Dish {
  id: string;
  name: string;
  japanese: string; // kanji name
  romaji: string; // romanisation
  category: "Nigiri" | "Maki" | "Course" | "Appetizer" | "Ramen" | "Rice" | "Noodle" | "Dessert";
  diet: DietTag[];
  price: string;
  image: string;
  tagline: string;
  description: string;
  ingredients: string[];
  hiddenIngredients?: HiddenIngredient[]; // things to confirm / watch for
  story: string;
  chefNote: string;
  pairing: string;
  accent: string; // accent colour hex
}

export const C = {
  // Theme-aware tokens (resolve via CSS variables, swap with light/dark)
  bg: "var(--sakura-bg)",
  bgSoft: "var(--sakura-bg-soft)",
  bgElev: "var(--sakura-bg-elev)",
  fg: "var(--sakura-fg)",
  fgMuted: "var(--sakura-fg-muted)",
  fgSoft: "var(--sakura-fg-soft)",
  card: "var(--sakura-card)",
  cardHi: "var(--sakura-card-hi)",
  border: "var(--sakura-border)",
  borderHi: "var(--sakura-border-hi)",
  overlay: "var(--sakura-overlay)",
  glass: "var(--sakura-glass)",
  // Fixed accents
  pink: "#ed2851",
  pink2: "#fff0f3",
  green: "#146b45",
  green2: "#e6f3eb",
  gold: "#f3b341",
  cream: "#fffaf5",
  ink: "#1f2933",
} as const;

/** Parse a price string like "¥1,200" into a number */
export function parsePrice(price: string): number {
  const digits = price.replace(/[^0-9]/g, "");
  return digits ? parseInt(digits, 10) : 0;
}

/** Format a number back into yen price */
export function formatPrice(n: number): string {
  return `¥${n.toLocaleString("en-US")}`;
}

export const dishes: Dish[] = [
  {
    id: "sakura-nigiri",
    name: "Sakura Nigiri",
    japanese: "桜にぎり",
    romaji: "Sakura Nigiri",
    category: "Nigiri",
    diet: ["omnivore"],
    price: "¥1,200",
    image: "/images/dish-nigiri.png",
    tagline: "Aged salmon, yuzu kosho",
    description:
      "A single piece of sushi, pressed by hand. The fish is aged two days to deepen its flavour, then cut across the grain so it melts on the tongue.",
    ingredients: [
      "Aged salmon (two-day)",
      "Akami shari (red-vinegar rice)",
      "Yuzu kosho",
      "Fresh shiso leaf",
    ],
    story:
      "Nigiri means 'pressed by hand'. At Sakura, each piece is shaped at body temperature — the warmth of the chef's palm sets the rice so it holds for the journey from counter to mouth, then falls apart the moment it arrives. This is the gesture sushi was built on: one hand, one piece, one breath.",
    chefNote:
      "We age the salmon for forty-eight hours. It loses water, gains depth, and the fat sweetens. Eat it with your fingers — that's how it was meant to be held.",
    pairing: "Junmai daiginjo, chilled",
    accent: C.pink,
  },
  {
    id: "hanami-maki",
    name: "Hanami Maki",
    japanese: "花見巻",
    romaji: "Hanami Maki",
    category: "Maki",
    diet: ["omnivore"],
    price: "¥1,600",
    image: "/images/dish-maki.png",
    tagline: "Salmon, avocado, shiso",
    description:
      "A roll named for hanami — the spring tradition of watching cherry blossoms fall. Pink salmon wraps the outside like petals on water.",
    ingredients: [
      "Salmon (toro)",
      "Avocado",
      "Shiso leaf",
      "Sesame",
      "Nori",
      "Shari",
    ],
    story:
      "Hanami is the Japanese custom of gathering under blooming sakura trees to eat, drink, and watch the petals fall. The first cherry blossom is a national news event in Japan — forecast nightly on television. This roll is shaped like that moment: pink on the outside, green inside, gone in a breath.",
    chefNote:
      "We roll it loose on purpose. A tight maki fights you. This one should almost come apart as you lift it — like a blossom letting go.",
    pairing: "Ginjo sake, lightly chilled",
    accent: C.pink,
  },
  {
    id: "yasai-maki",
    name: "Yasai Maki",
    japanese: "野菜巻",
    romaji: "Yasai Maki",
    category: "Maki",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥1,100",
    image: "/images/dish-yasai-maki.png",
    tagline: "Seasonal vegetable roll",
    description:
      "A garden in a roll. Carrot, avocado, cucumber and pickled cabbage — no fish, no egg, no dashi. Just vegetables and rice seasoned with vinegar.",
    ingredients: [
      "Avocado",
      "Carrot",
      "Cucumber",
      "Pickled cabbage (no fish stock)",
      "Nori",
      "Shari (rice vinegar only)",
    ],
    story:
      "Yasai means 'vegetables'. In Japan, vegetable sushi was once a temple food — eaten by Buddhist monks who avoided killing. Today it is a quiet art of its own: the chef learns to coax sweetness from a carrot the way others coax umami from a fish. The knife work is slower, and the respect is the same.",
    chefNote:
      "We salt-roast the carrots first. They caramelise in their own juices. No dashi, no bonito — every seasoning here is plant-based, confirmed at the counter.",
    pairing: "Hojicha (roasted green tea)",
    accent: C.green,
  },
  {
    id: "hiyayakko",
    name: "Hiyayakko",
    japanese: "冷奴",
    romaji: "Hiyayakko",
    category: "Appetizer",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥800",
    image: "/images/dish-tofu.png",
    tagline: "Chilled silken tofu, scallion, ginger",
    description:
      "Cold silken tofu, topped with grated ginger and scallion, finished with a pour of soy. The simplest dish on the counter, and the hardest to get right.",
    ingredients: [
      "Silken tofu",
      "Scallion",
      "Grated ginger",
      "Tamari soy (gluten-free option)",
    ],
    story:
      "Hiyayakko is the dish a Japanese cook is judged by. There is nowhere to hide — no sauce, no heat, no garnish to mask the tofu. If the tofu is good, you taste the soybean, the water, the mountain morning it was made. It is the first thing served in summer, and the last thing a chef wants to get wrong.",
    chefNote:
      "We use tofu pressed each morning at a workshop in Indiranagar. It arrives still warm. We chill it for four hours before serving — never longer.",
    pairing: "Cold Junmai sake",
    accent: C.green,
  },
  {
    id: "kappa-maki",
    name: "Kappa Maki",
    japanese: "河童巻",
    romaji: "Kappa Maki",
    category: "Maki",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥600",
    image: "/images/dish-kappa.png",
    tagline: "Cucumber roll, sesame",
    description:
      "Crisp cucumber wrapped in nori and rice. A children's sushi in Japan, and a palate cleanser between richer pieces for adults.",
    ingredients: ["Cucumber", "Nori", "Shari", "Toasted sesame"],
    story:
      "The kappa is a river spirit from Japanese folklore — mischievous, water-loving, and famously fond of cucumbers. Mothers would write their children's names on cucumbers and toss them into rivers to keep the kappa happy. This roll carries the spirit's name, and its favourite food.",
    chefNote:
      "We seed the cucumber. The seeds hold water, and water breaks the rice. It is the smallest roll we make, and the one we eat between courses.",
    pairing: "Sencha green tea",
    accent: C.green,
  },
  {
    id: "edamame-gunkan",
    name: "Edamame Gunkan",
    japanese: "枝豆軍艦",
    romaji: "Edamame Gunkan",
    category: "Nigiri",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥900",
    image: "/images/dish-edamame.png",
    tagline: "Young soybean battleship",
    description:
      "A 'battleship' of nori cradling mashed edamame atop a bed of rice. Salty, green, and quietly rich.",
    ingredients: [
      "Edamame (young soybean)",
      "Nori",
      "Shari",
      "Sea salt",
    ],
    story:
      "Gunkan means 'warship' — the nori walls rise around the rice like the hull of a ship, holding in toppings too soft to stand alone. Edamame, the young soybean picked before it hardens, is a summer food in Japan: boiled in salted water, popped from the pod with the thumb, eaten with cold beer on a warm evening. Here it is mashed, seasoned, and set afloat.",
    chefNote:
      "We shell each bean by hand. The pod gives the bean a grassy smell we don't want in the mash — so the pod never touches the rice.",
    pairing: "Cold lager or mugicha barley tea",
    accent: C.green,
  },
  {
    id: "omakase",
    name: "Omakase Course",
    japanese: "お任せ",
    romaji: "Omakase",
    category: "Course",
    diet: ["omnivore"],
    price: "¥6,800",
    image: "/images/hero-sushi.png",
    tagline: "Chef's selection, nine pieces",
    description:
      "Omakase — 'I leave it to you'. Nine pieces, chosen by the chef, served one at a time across ninety minutes at the counter.",
    ingredients: [
      "Nine seasonal pieces",
      "Soup",
      "Dessert",
      "Chef's choice throughout",
    ],
    story:
      "Omakase is the deepest kind of trust a diner can offer, and the highest a chef can earn. There is no menu. You sit. The chef watches you eat, adjusts the next piece to your pace, your preference, your mood. It is a conversation with no words — just fish, rice, and the space between. Each night is different. Each course is a sentence the chef is finishing only for you.",
    chefNote:
      "We take nine seats each evening, two seatings. Bookings open a week ahead. Tell us your preferences — including plant-based — and we will shape the course around you.",
    pairing: "A progression — sake, then tea",
    accent: C.gold,
  },
];

/* ------------------------------------------------------------------ */
/*  New vegetarian / vegan / Jain Japanese dishes                      */
/*  Inspired by AARY VLOGS Japan tour — the street-temple-home foods   */
/*  many Indian travellers actually find and love in Japan.            */
/* ------------------------------------------------------------------ */
dishes.push(
  {
    id: "inari-zushi",
    name: "Inari Sushi",
    japanese: "稲荷寿司",
    romaji: "Inari-zushi",
    category: "Appetizer",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥700",
    image: "/images/dish-inari.png",
    tagline: "Sweet fried tofu pouches, vinegared rice",
    description:
      "Pillows of deep-fried tofu, simmered in a sweet soy glaze, stuffed with vinegared rice. Eaten with the fingers, often at shrines and on picnic blankets.",
    ingredients: [
      "Abura-age (fried tofu pouches)",
      "Shari (rice vinegar, sugar, salt)",
      "Sesame",
      "Rice-vinegar tare (no dashi)",
    ],
    hiddenIngredients: [
      { name: "Dashi in the simmering broth", risk: "medium", note: "Classic inari is simmered in a dashi-soy broth. We use a kombu/shiitake dashi so it stays plant-based — but at most Japanese shops the broth contains bonito. Always ask." },
      { name: "Sugar type", risk: "low", note: "Some traditional recipes use mirin (sweet rice wine). We use sugar; confirm elsewhere if alcohol matters to you." },
    ],
    story:
      "Inari sushi is named after Inari, the Shinto deity of rice, fertility and foxes — whose messengers are white foxes said to love fried tofu. Pilgrims carried these sweet pouches to mountain shrines for centuries. Travellers in Japan (AARY VLOGS among them) often spot inari at konbini and temples alike: cheap, portable, and quietly one of the oldest vegetarian foods in the country.",
    chefNote:
      "We boil the abura-age twice to lift the oil, then simmer it for twenty minutes in our kombu tare. The pouch should be warm, glossy, and just sweet enough to balance the rice.",
    pairing: "Sencha green tea",
    accent: C.gold,
  },
  {
    id: "nasu-dengaku",
    name: "Nasu Dengaku",
    japanese: "茄子田楽",
    romaji: "Nasu Dengaku",
    category: "Appetizer",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥950",
    image: "/images/dish-nasu.png",
    tagline: "Miso-glazed half eggplant",
    description:
      "Japanese eggplant, grilled soft, brushed with a sweet miso glaze and finished with sesame. Smoky, sweet, and almost custardy inside.",
    ingredients: [
      "Japanese eggplant (nasu)",
      "White miso (shiro-miso)",
      "Mirin substitute (rice syrup)",
      "Sake substitute (rice water)",
      "Sesame seeds",
    ],
    hiddenIngredients: [
      { name: "Dashi in miso glaze", risk: "medium", note: "Restaurant miso glazes often include dashi or katsuobushi-infused mirin. We use a kombu base — confirm at every other place." },
      { name: "Mirin (alcohol)", risk: "medium", note: "Real mirin is sweet cooking wine. Some observant guests avoid it; we substitute rice syrup + water on request." },
    ],
    story:
      "Dengaku goes back eight hundred years — to farmers who danced on stilts (dengaku) for a good harvest, and grilled skewered tofu and eggplant glazed with miso at the festival. The dance gave the dish its name. Eggplant came to Japan via China and was once a luxury; miso on eggplant was a peasant's sweet.",
    chefNote:
      "We score the flesh in a diamond so the glaze sinks in. Then we grill skin-down until the inside turns to silk. The miso must never burn — only warm until it glosses.",
    pairing: "Junmai sake, room temperature",
    accent: C.pink,
  },
  {
    id: "agedashi-tofu",
    name: "Agedashi Tofu",
    japanese: "揚げ出し豆腐",
    romaji: "Agedashi-dofu",
    category: "Appetizer",
    diet: ["vegetarian", "jain-friendly"],
    price: "¥1,000",
    image: "/images/dish-agedashi.png",
    tagline: "Crisp silken tofu in a light broth",
    description:
      "Silken tofu dusted in potato starch and flash-fried, set in a warm pool of seasoned broth with daikon and scallion. The outside is glassy-crisp; the inside, a cloud.",
    ingredients: [
      "Silken tofu",
      "Potato starch (katakuriko)",
      "Kombu & shiitake dashi (plant-based)",
      "Daikon oroshi (grated radish)",
      "Scallion",
      "Tamari soy",
    ],
    hiddenIngredients: [
      { name: "Bonito dashi", risk: "high", note: "The classic broth is katsuo-dashi — fish stock. This is the single biggest hidden-ingredient trap for vegetarians in Japan. Ask: 'kombu-dashi dekimasu ka?' (Can you make it with kelp broth?)" },
      { name: "Katsuobushi garnish", risk: "medium", note: "Many shops top agedashi with bonito flakes that curl in the heat. Visually obvious, but easy to forget when ordering." },
    ],
    story:
      "Agedashi tofu is over three hundred years old — a dish from old Edo. The trick is the contrast: a crisp skin that holds for seconds, then a broth that floods the mouth. The original uses fish dashi; ours uses kombu and dried shiitake, the way Buddhist temple kitchens have for a thousand years.",
    chefNote:
      "We drain the tofu under a light weight for an hour. Wet tofu spits in the oil and the starch slides off. Patience first, fry second.",
    pairing: "Cold Junmai sake or hojicha",
    accent: C.green,
  },
  {
    id: "yasai-tempura",
    name: "Yasai Tempura",
    japanese: "野菜天ぷら",
    romaji: "Yasai Tempura",
    category: "Appetizer",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥1,300",
    image: "/images/dish-tempura.png",
    tagline: "Seasonal vegetables, light batter",
    description:
      "Sweet potato, shiso leaf, lotus root and pumpkin, dipped in a cold water-flour batter and fried to a lace shell. Served with a plant-based tentsuyu and salt.",
    ingredients: [
      "Seasonal vegetables (sweet potato, lotus root, shiso, pumpkin)",
      "Flour + iced water batter",
      "Kombu-shiitake tentsuyu (dipping broth)",
      "Sea salt",
      "Grated daikon",
    ],
    hiddenIngredients: [
      { name: "Dashi in tentsuyu", risk: "high", note: "The classic tempura dipping sauce is made with katsuo-dashi. Ask for 'kombu-dashi' tentsuyu or simply use salt — many purists do." },
      { name: "Shared oil", risk: "medium", note: "Restaurants often fry shrimp and vegetables in the same oil. If strict, ask: 'ebi to onaji abura desu ka?' (Is it the same oil as the shrimp?)" },
      { name: "Egg in batter", risk: "medium", note: "Some tempura batters include egg for colour. Ours is flour + water only — confirm elsewhere." },
    ],
    story:
      "Tempura came to Japan with Portuguese missionaries in the sixteenth century — the word derives from 'tempora', the Catholic meatless days. So tempura was, by origin, a vegetarian food. Over time Japan added seafood, but the vegetable version remains, and Buddhist temples still fry it for visitors on meatless days.",
    chefNote:
      "The batter must stay lumpy and ice-cold. We mix it once, never twice. Over-mixing makes it bread. We want it to shatter, like a leaf.",
    pairing: "Cold Junmai sake or mugicha",
    accent: C.gold,
  },
  {
    id: "vegan-shoyu-ramen",
    name: "Vegan Shoyu Ramen",
    japanese: "野菜醤油ラーメン",
    romaji: "Yasai Shoyu Ramen",
    category: "Ramen",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥1,400",
    image: "/images/dish-ramen.png",
    tagline: "Plant-based soy broth, noodles, vegetables",
    description:
      "A clear soy-seasoned broth built on kombu, shiitake and root vegetables. Hand-pulled noodles, scallion, nori, corn and bamboo. A bowl you can drink to the bottom.",
    ingredients: [
      "Kombu & shiitake broth",
      "Root vegetable base (onion, carrot, ginger)",
      "Soy sauce (tamari option)",
      "Ramen noodles (no egg)",
      "Scallion, corn, bamboo, nori",
    ],
    hiddenIngredients: [
      { name: "Pork / tonkotsu base", risk: "high", note: "Most ramen in Japan is pork-based, even when 'vegetable' is on the sign. The broth itself is the issue. Ask: 'tonkotsu wa haitte imasu ka?' (Does it contain pork bone?)" },
      { name: "Bonito (katsuo)", risk: "high", note: "Shoyu ramen broth almost always contains katsuo-dashi. The clearest phrase is: 'katsuo nashi, kombu-dashi de' (no bonito, kelp broth only)." },
      { name: "Noodles with egg", risk: "medium", note: "Some ramen noodles are made with egg. Ours are flour + water + kansui (alkaline water) only." },
      { name: "Menma (fermented bamboo)", risk: "low", note: "Sometimes fermented with fish. Ours is plain." },
    ],
    story:
      "Ramen is Chinese in origin, Japanese by adoption, and a national obsession. Each region — Hakata, Sapporo, Tokyo — has its own bowl. For a vegetarian traveller, ramen is the hardest dish to find clean in Japan: the broth is almost always pork or bonito. Our version is built from the ground up on kombu and root vegetables — the way Buddhist monks made it before ramen became meat.",
    chefNote:
      "We simmer the kombu at 60°C for an hour, never boiling it (boiling makes kombu bitter). We add dried shiitake for body, and soy at the end. Twelve hours of patience for one bowl.",
    pairing: "Cold mugicha barley tea",
    accent: C.green,
  },
  {
    id: "onigiri-umeboshi",
    name: "Onigiri (Ume)",
    japanese: "おにぎり",
    romaji: "Onigiri",
    category: "Rice",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥400",
    image: "/images/dish-onigiri.png",
    tagline: "Rice triangle, pickled plum, nori",
    description:
      "A triangle of warm rice, salted on the outside, filled with pickled plum (umeboshi), wrapped in crisp nori. The food of picnics, trains and gods.",
    ingredients: [
      "Short-grain rice",
      "Sea salt",
      "Umeboshi (pickled plum)",
      "Nori",
    ],
    hiddenIngredients: [
      { name: "Katsuobushi filling", risk: "high", note: "Konbini onigiri fillings often include bonito (okaka) or tuna-mayo. Read the label or ask — the 'ume' version is almost always safe." },
      { name: "Flavour enhancer", risk: "low", note: "Some commercial rice seasoning uses dashi powder. Our onigiri is rice, salt, plum, nori — nothing else." },
    ],
    story:
      "Onigiri may be the oldest convenience food in the world — rice pressed into a shape a hand can hold, found in eleventh-century literature. Samurai carried them into battle; mothers packed them for school trips. The pickled-plum filling was chosen because ume is a natural preservative. Travellers on the shinkansen still eat them today, bought at the platform konbini.",
    chefNote:
      "We salt the hands, not the rice — salt on the outside is the old way. The nori is wrapped last, just before eating, so it stays crisp against the warm rice.",
    pairing: "Hot sencha or hojicha",
    accent: C.pink,
  },
  {
    id: "zaru-soba",
    name: "Zaru Soba",
    japanese: "ざるそば",
    romaji: "Zaru Soba",
    category: "Noodle",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥1,000",
    image: "/images/dish-soba.png",
    tagline: "Cold buckwheat noodles, dipping broth",
    description:
      "Cold buckwheat noodles served on a bamboo mat, with a cup of mentsuyu dipping broth, scallion and wasabi. The summer bowl of Japan — light, clean, fast.",
    ingredients: [
      "Buckwheat noodles (soba)",
      "Kombu-shiitake mentsuyu",
      "Scallion",
      "Wasabi",
      "Nori strips",
    ],
    hiddenIngredients: [
      { name: "Bonito in mentsuyu", risk: "high", note: "Mentsuyu is traditionally katsuo-dashi based. This is the trap of soba: the broth, not the noodles. Ask for 'kombu-dashi no mentsuyu'." },
      { name: "Wheat in soba", risk: "medium", note: "Pure soba is 100% buckwheat, but many shops cut it with wheat for texture. Coeliac guests must ask for 'jūwari soba' (100% soba)." },
      { name: "Shared boiling water", risk: "low", note: "Some shops boil soba and udon (wheat) in the same pot." },
    ],
    story:
      "Soba is the food of Edo's merchants — eaten cold in summer, hot in winter, often standing at a counter in under three minutes. There is a whole etiquette: you sip the noodles loudly (it cools them and opens the aroma), and you finish by pouring your soba-yu — the water the noodles were boiled in — into the remaining broth, and drinking it. Nothing is wasted.",
    chefNote:
      "We knead the dough by hand with cold water — buckwheat has no gluten, so it fights you. Rest it, roll it, cut it thin. Boil sixty seconds. Shock in ice water. Done.",
    pairing: "Cold sake or hojicha",
    accent: C.green,
  },
  {
    id: "matcha-mochi",
    name: "Matcha Mochi",
    japanese: "抹茶餅",
    romaji: "Matcha Mochi",
    category: "Dessert",
    diet: ["vegan", "vegetarian", "jain-friendly"],
    price: "¥600",
    image: "/images/dish-mochi.png",
    tagline: "Green-tea rice-cake, dusted",
    description:
      "Soft pounded rice cake, flavoured with stone-ground matcha, dusted in more matcha and kinako (roasted soybean flour). Chewy, bittersweet, gone in two bites.",
    ingredients: [
      "Mochi rice (pounded)",
      "Matcha (ceremonial grade)",
      "Kinako (roasted soybean flour)",
      "Rice syrup",
    ],
    hiddenIngredients: [
      { name: "Honey / dairy", risk: "low", note: "Some mochi is glazed with honey or filled with dairy cream. Our mochi is rice + matcha + kinako only — confirm at konbini where dairy fillings are common." },
      { name: "White sugar with bone char", risk: "low", note: "Strict vegans sometimes avoid refined white sugar processed with bone char. We use rice syrup to avoid the question." },
    ],
    story:
      "Mochi is older than sushi — pounded rice has been a sacred food in Japan for over a thousand years, offered to the gods at New Year and cut at festivals. The matcha here is the same tea used in the tea ceremony; the kinako is roasted soybean flour, a protein-rich sweetener from temple kitchens. Together they make a sweet that is almost sugar-free and entirely plant-based.",
    chefNote:
      "We pound the mochi while it is hot, with a wooden mallet in a stone usu. Cold mochi breaks. The matcha must be sifted three times or it clumps. Eat it the day it is made — mochi does not wait.",
    pairing: "Usucha (thin matcha)",
    accent: C.green,
  },
);

export const dietFilters: { key: DietTag | "all"; label: string; japanese: string }[] = [
  { key: "all", label: "All dishes", japanese: "全部" },
  { key: "vegetarian", label: "Vegetarian", japanese: "菜食" },
  { key: "vegan", label: "Vegan", japanese: "精進" },
  { key: "jain-friendly", label: "Jain-friendly", japanese: "ジャイナ" },
];
