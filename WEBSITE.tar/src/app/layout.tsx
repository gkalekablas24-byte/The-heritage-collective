import type { Metadata } from "next";
import { Geist, Cormorant_Garamond } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  style: ["normal", "italic"],
});

const SITE_URL = "https://sakura-sushi-bar.example";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Sakura Sushi Bar — Handcrafted Japanese Cuisine",
    template: "%s · Sakura Sushi Bar",
  },
  description:
    "Sakura Sushi Bar is a Japanese counter in Indiranagar, Bengaluru — handcrafted maki, nigiri, ramen, soba and plant-based dishes. View the menu, plan by diet & budget, and book a table.",
  applicationName: "Sakura Sushi Bar",
  keywords: [
    "Sakura Sushi Bar",
    "Japanese restaurant Bengaluru",
    "sushi Indiranagar",
    "vegan sushi",
    "vegetarian Japanese",
    "Jain-friendly Japanese",
    "omakase",
    "book a table",
  ],
  authors: [{ name: "Sakura Sushi Bar" }],
  creator: "Sakura Sushi Bar",
  publisher: "Sakura Sushi Bar",
  alternates: {
    canonical: "/",
  },
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
    apple: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  manifest: "/manifest.webmanifest",
  openGraph: {
    title: "Sakura Sushi Bar — Handcrafted Japanese Cuisine",
    description:
      "Handcrafted maki, nigiri, ramen and plant-based dishes. An honest guide to eating Japanese food your way — vegan, vegetarian and Jain-friendly.",
    url: SITE_URL,
    siteName: "Sakura Sushi Bar",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sakura Sushi Bar",
    description: "Handcrafted Japanese cuisine, made personal.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  category: "food",
};

// Inline script to set the theme class before hydration (prevents flash)
const themeScript = `
(function(){try{
  var t = localStorage.getItem('sakura-theme');
  if(!t){ t = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'; }
  if(t === 'light'){ document.documentElement.classList.add('light'); document.documentElement.classList.remove('dark'); }
  else { document.documentElement.classList.add('dark'); document.documentElement.classList.remove('light'); }
}catch(e){ document.documentElement.classList.add('dark'); }
})();
`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body
        className={`${geistSans.variable} ${cormorant.variable} antialiased`}
      >
        <ThemeProvider>{children}</ThemeProvider>
        <Toaster />
      </body>
    </html>
  );
}
