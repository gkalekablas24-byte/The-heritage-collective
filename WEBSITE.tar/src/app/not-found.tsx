import Link from "next/link";

/**
 * 404 page — server component (no framer-motion) since not-found.tsx is a
 * reserved Next.js file that renders on the server.
 */
export default function NotFound() {
  return (
    <div
      className="grid min-h-screen place-items-center px-6"
      style={{ background: "#1f2933", color: "#fffaf5" }}
    >
      <div className="max-w-md text-center" style={{ animation: "sakura-fade 0.6s ease-out" }}>
        <span
          className="mx-auto grid h-16 w-16 place-items-center rounded-full font-serif text-[28px] font-semibold text-white"
          style={{ background: "linear-gradient(145deg, #ed2851, #b71e3e)" }}
        >
          桜
        </span>
        <p
          className="mt-6 font-serif text-[13px] tracking-[0.3em]"
          style={{ color: "#f3b341" }}
        >
          404 · 見つかりません
        </p>
        <h1 className="mt-2 font-serif text-[38px] font-medium leading-tight">
          This page wandered off.
        </h1>
        <p
          className="mt-3 text-[14px] leading-relaxed"
          style={{ color: "rgba(255,250,245,0.7)" }}
        >
          The counter is still open. Let&apos;s get you back to the menu.
        </p>
        <Link
          href="/"
          className="mt-7 inline-flex items-center gap-2 rounded-[12px] px-6 py-3 text-[12px] font-semibold tracking-[0.18em] uppercase text-white"
          style={{ background: "#ed2851" }}
        >
          ← Back to Sakura
        </Link>
      </div>
      <style>{`
        @keyframes sakura-fade {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
