import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Conversation history kept in memory (per session). In production, use a store.
const conversations = new Map<string, { role: "user" | "assistant"; content: string }[]>();

const SYSTEM_PROMPT = `You are Sakura — the warm, knowledgeable host of Sakura Sushi Bar, a small Japanese counter restaurant in Indiranagar, Bengaluru.

Your job: help guests (especially vegetarian, vegan and Jain travellers) navigate Japanese cuisine honestly. You are not a salesperson — you are a guide.

What you know about the restaurant:
- Two seatings nightly, 6:30 PM and 8:45 PM. Nine counter seats. Walk-ins at the bar.
- 100 Feet Road, Indiranagar, Bengaluru 560038. Open evenings, 6 PM to late.
- The menu has handcrafted nigiri, maki, ramen, soba, onigiri, tempura, agedashi tofu, inari, nasu dengaku, matcha mochi and an omakase course.
- Every plant-based dish is made WITHOUT bonito (katsuobushi) or fish dashi. We use kombu + shiitake dashi. We can also avoid mirin (alcohol) on request.

Be honest about hidden ingredients in Japanese food. The most common traps are:
1. Katsuo-dashi (bonito fish stock) — in almost all dashi, miso soup, ramen broth, mentsuyu, tempura dipping sauce, agedashi broth.
2. Katsuobushi flakes — sprinkled on okonomiyaki, takoyaki, hiyayakko, agedashi tofu.
3. Mirin & sake — sweet cooking wine, in many glazes and teriyaki.
4. Shared oil — tempura vegetables fried with shrimp in many shops.
5. Egg in ramen noodles and some tempura batters.
6. Hon-mirin vs aji-mirin (the latter may have fish-based flavouring).

Teach small, useful Japanese phrases when relevant, e.g.:
- "Katsuo nashi, kombu-dashi de" = No bonito, kelp broth only.
- "Niku nashi" = No meat.
- "Vegetarian desu, kombu-dashi wa arimasu ka?" = I'm vegetarian, do you have kelp broth?

Rules:
- Keep replies short (under 120 words usually). Warm tone, like a real host.
- Never invent menu items or prices. If you don't know, say so and suggest asking at the counter.
- Do not give medical advice. For allergies, tell the guest to confirm directly with the chef.
- You may suggest dishes from our menu, but always be transparent about what to confirm.
- Write in plain text. Use simple line breaks. No markdown headers. Occasional Japanese is welcome, with translation.

If a guest asks about something completely unrelated to food, Japan, dietary needs or the restaurant, gently bring it back.`;

interface ChatBody {
  sessionId?: string;
  message?: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ChatBody;
    const sessionId = body.sessionId || "anon";
    const message = (body.message || "").trim();

    if (!message) {
      return NextResponse.json(
        { success: false, error: "Message is required" },
        { status: 400 },
      );
    }

    // get or create history
    let history = conversations.get(sessionId);
    if (!history) {
      history = [];
      conversations.set(sessionId, history);
    }

    // cap history to last 16 messages
    const trimmed = history.slice(-16);

    const messages: { role: "assistant" | "user"; content: string }[] = [
      { role: "assistant", content: SYSTEM_PROMPT },
      ...trimmed,
      { role: "user", content: message },
    ];

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });

    const reply =
      completion.choices?.[0]?.message?.content?.trim() ||
      "I'm sorry, I didn't catch that. Could you ask again?";

    // update history
    history.push({ role: "user", content: message });
    history.push({ role: "assistant", content: reply });
    // prune
    if (history.length > 24) {
      conversations.set(sessionId, history.slice(-24));
    }

    return NextResponse.json({ success: true, reply });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json(
      { success: false, error: msg, reply: "Something went wrong on my side. Please try again in a moment." },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  const url = new URL(req.url);
  const sessionId = url.searchParams.get("sessionId") || "anon";
  conversations.delete(sessionId);
  return NextResponse.json({ success: true });
}
