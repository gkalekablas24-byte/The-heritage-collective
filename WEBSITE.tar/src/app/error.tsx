"use client";

import { useEffect } from "react";

/**
 * Global error boundary — catches render errors anywhere in the tree
 * and shows a calm, on-brand fallback. Uses CSS animation (not framer-motion)
 * so it renders even if the motion library failed to load.
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Sakura render error:", error);
  }, [error]);

  return (
    <div
      className="grid min-h-screen place-items-center px-6"
      style={{ background: "#1f2933", color: "#fffaf5" }}
    >
      <div
        className="max-w-md text-center"
        style={{ animation: "sakura-fade 0.6s ease-out" }}
      >
        <span
          className="mx-auto grid h-16 w-16 place-items-center rounded-full font-serif text-[28px] font-semibold text-white"
          style={{ background: "linear-gradient(145deg, #ed2851, #b71e3e)" }}
        >
          桜
        </span>
        <h1 className="mt-6 font-serif text-[34px] font-medium leading-tight">
          A small pause in the kitchen.
        </h1>
        <p
          className="mt-3 text-[14px] leading-relaxed"
          style={{ color: "rgba(255,250,245,0.7)" }}
        >
          Something didn&apos;t render as expected. The chef is looking at it.
          You can try again — the counter is still open.
        </p>
        <button
          onClick={reset}
          className="mt-7 inline-flex items-center gap-2 rounded-[12px] px-6 py-3 text-[12px] font-semibold tracking-[0.18em] uppercase text-white"
          style={{ background: "#ed2851" }}
        >
          Try again →
        </button>
        {error.digest ? (
          <p
            className="mt-4 text-[11px]"
            style={{ color: "rgba(255,250,245,0.4)" }}
          >
            Ref: {error.digest}
          </p>
        ) : null}
      </div>
      <style>{`
        @keyframes sakura-fade {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
