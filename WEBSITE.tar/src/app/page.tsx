"use client";

import { useRef, useState, useMemo } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useInView,
  useMotionValue,
  useSpring,
  AnimatePresence,
  type Variants,
} from "framer-motion";
import {
  Menu,
  X,
  Instagram,
  Twitter,
  ArrowUpRight,
  Leaf,
  Sparkles,
  Plus,
  Check,
} from "lucide-react";
import { dishes, dietFilters, C, type DietTag } from "@/lib/dishes";
import { SakuraPetals } from "@/components/sakura/petals";
import { DishModal } from "@/components/sakura/dish-modal";
import { TiltCard } from "@/components/sakura/tilt-card";
import { MagneticButton } from "@/components/sakura/magnetic-button";
import { AnimatedCounter } from "@/components/sakura/animated-counter";
import { TrayButton, TrayDrawer } from "@/components/sakura/tray-drawer";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { HiddenIngredientsMap } from "@/components/sakura/hidden-ingredients-map";
import { FoodPlanner } from "@/components/sakura/food-planner";
import { ChatbotWidget } from "@/components/sakura/chatbot-widget";
import { useTray, selectAdd } from "@/lib/tray-store";
import { parsePrice, formatPrice } from "@/lib/dishes";

/* ------------------------------------------------------------------ */
/*  Motion variants                                                    */
/* ------------------------------------------------------------------ */
const fadeUp: Variants = {
  hidden: { opacity: 0, y: 36 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] },
  },
};
const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};
const panelReveal: Variants = {
  hidden: { opacity: 0, y: 60, scale: 0.98 },
  show: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 1, ease: [0.22, 1, 0.36, 1] },
  },
};

/* ------------------------------------------------------------------ */
/*  Static content                                                      */
/* ------------------------------------------------------------------ */
const sidePanels = [
  { label: "Menu", sub: "Handcrafted maki & nigiri", image: "/images/menu-sushi.png", accent: C.pink, href: "#menu" },
  { label: "Reservation", sub: "Reserve your evening", image: "/images/reservation-dining.png", accent: C.gold, href: "#reservation" },
  { label: "The Room", sub: "Inside Sakura", image: "/images/restaurant-interior.png", accent: C.green, href: "#culture" },
  { label: "After Dark", sub: "Nights in the city", image: "/images/neon-sign.png", accent: C.pink, href: "#culture" },
];

const categories: { key: "all" | Dish["category"]; label: string; jp: string }[] = [
  { key: "all", label: "All", jp: "全部" },
  { key: "Nigiri", label: "Nigiri", jp: "握り" },
  { key: "Maki", label: "Maki", jp: "巻物" },
  { key: "Appetizer", label: "Appetizer", jp: "前菜" },
  { key: "Ramen", label: "Ramen", jp: "ラーメン" },
  { key: "Rice", label: "Rice", jp: "ご飯" },
  { key: "Noodle", label: "Noodle", jp: "麺" },
  { key: "Course", label: "Course", jp: "コース" },
  { key: "Dessert", label: "Dessert", jp: "甘味" },
];

const foodStories = [
  {
    kanji: "職人", romaji: "Shokunin",
    title: "The hand that presses the rice",
    excerpt: "A sushi chef trains for ten years before being allowed to press nigiri for a guest. The first three are spent only washing rice. The next two, only making rice. The skill is not in the fish — it is in the grain.",
    image: "/images/chef-hands.png", accent: C.gold,
  },
  {
    kanji: "旬", romaji: "Shun",
    title: "Eating the season",
    excerpt: "Shun is the moment a food is at its peak — the day the first mackerel runs, the hour the bamboo shoot breaks earth. Japanese menus follow it like weather. Our counter changes every week.",
    image: "/images/dish-yasai-maki.png", accent: C.green,
  },
  {
    kanji: "和食", romaji: "Washoku",
    title: "The harmony of a meal",
    excerpt: "Washoku — the traditional food of Japan — is built on five: five colours, five flavours, five methods, on five plates. Each meal seeks balance, not abundance. Even our simplest course follows the rule.",
    image: "/images/dish-tofu.png", accent: C.pink,
  },
];

const cultureItems = [
  { kanji: "お任せ", romaji: "Omakase", title: "I leave it to you", body: "The deepest trust a diner can give. No menu — the chef reads your pace and shapes each piece in reply. Nine seats. Two seatings. One conversation.", accent: C.pink },
  { kanji: "和食", romaji: "Washoku", title: "The harmony of food", body: "Japan's traditional cuisine — built on five colours, five flavours, five methods. A meal that seeks balance over abundance. UNESCO heritage, since 2013.", accent: C.green },
  { kanji: "もてなし", romaji: "Omotenashi", title: "Hospitality, anticipated", body: "To care for a guest so completely that nothing needs asking. The glass refilled before empty, the chair turned before you sit. Service as a quiet art.", accent: C.gold },
];

/* ------------------------------------------------------------------ */
/*  Page                                                               */
/* ------------------------------------------------------------------ */
export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const heroImageY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);
  const heroTextY = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  const heroTextOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  // window scroll progress for the top bar — single subscription
  const { scrollYProgress: windowProgress } = useScroll();

  // cursor-follow glow on hero
  const glowX = useMotionValue(-200);
  const glowY = useMotionValue(-200);
  const sGlowX = useSpring(glowX, { stiffness: 120, damping: 20 });
  const sGlowY = useSpring(glowY, { stiffness: 120, damping: 20 });

  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<DietTag | "all">("all");
  const [activeCategory, setActiveCategory] = useState<"all" | Dish["category"]>("all");
  const [selectedDishId, setSelectedDishId] = useState<string | null>(null);

  const selectedDish = useMemo(
    () => dishes.find((d) => d.id === selectedDishId) ?? null,
    [selectedDishId],
  );

  const filteredDishes = useMemo(() => {
    return dishes.filter((d) => {
      const dietOk = activeFilter === "all" || d.diet.includes(activeFilter);
      const catOk = activeCategory === "all" || d.category === activeCategory;
      return dietOk && catOk;
    });
  }, [activeFilter, activeCategory]);

  function onHeroMove(e: React.MouseEvent<HTMLDivElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    glowX.set(e.clientX - r.left);
    glowY.set(e.clientY - r.top);
  }

  return (
    <main
      className="relative min-h-screen w-full overflow-x-hidden"
      style={{ background: C.bg, color: C.fg }}
    >
      <SakuraPetals count={18} />

      {/* top scroll progress */}
      <motion.div
        className="fixed left-0 right-0 top-0 z-[60] h-[3px] origin-left"
        style={{ scaleX: windowProgress, background: `linear-gradient(90deg, ${C.pink}, ${C.gold})` }}
      />

      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      {/* ============ Hero ============ */}
      <section ref={heroRef} className="relative w-full px-4 pb-6 pt-24 sm:px-6 sm:pt-28 lg:px-8">
        <div className="mx-auto max-w-[1480px]">
          <motion.div initial="hidden" animate="show" variants={stagger} className="mb-5 flex items-center justify-between">
            <motion.span variants={fadeUp} className="flex items-center gap-2 text-[11px] font-medium tracking-label" style={{ color: C.green }}>
              <motion.span animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} className="inline-block">✦</motion.span>
              和食 · Japanese cuisine, made personal
            </motion.span>
            <motion.span variants={fadeUp} className="hidden text-[11px] tracking-label sm:inline" style={{ color: C.fgMuted }}>
              Indiranagar · Bengaluru
            </motion.span>
          </motion.div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-12 lg:gap-3">
            {/* Left column */}
            <motion.div
              initial="hidden" animate="show" variants={panelReveal}
              onMouseMove={onHeroMove}
              className="relative overflow-hidden rounded-[20px] lg:col-span-8"
              style={{ background: C.bgSoft }}
            >
              <motion.div style={{ y: heroImageY }} className="absolute inset-0 scale-110">
                <img src="/images/hero-sushi.png" alt="Handcrafted sushi platter at Sakura Sushi Bar" className="h-full w-full object-cover" fetchPriority="high" />
              </motion.div>

              {/* cursor glow */}
              <motion.div
                aria-hidden
                className="cursor-glow"
                style={{
                  x: sGlowX, y: sGlowY,
                  width: 320, height: 320,
                  translateX: "-50%", translateY: "-50%",
                  background: "var(--sakura-glow-pink)",
                }}
              />

              <div className="pointer-events-none absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(31,41,51,0.25) 0%, rgba(31,41,51,0.05) 35%, rgba(31,41,51,0.55) 75%, rgba(31,41,51,0.92) 100%)" }} />

              <motion.div
                initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6, duration: 0.8 }}
                className="absolute right-5 top-5 hidden max-w-[210px] rounded-[14px] p-4 backdrop-blur-md sm:block"
                style={{ background: "rgba(20,31,35,0.55)", border: `1px solid rgba(243,179,65,0.25)` }}
              >
                <span className="text-[10px] font-bold tracking-label" style={{ color: C.gold }}>Omakase · 今夜</span>
                <p className="mt-1 text-[12px] leading-snug text-white/90">A nine-course tasting at the counter. Limited seats.</p>
              </motion.div>

              <div className="vertical-rl pointer-events-none absolute left-5 top-6 text-[13px] tracking-[0.3em]" style={{ color: "rgba(255,250,245,0.55)" }}>桜 · すし</div>

              <motion.div style={{ y: heroTextY, opacity: heroTextOpacity }} className="relative z-10 flex h-full flex-col justify-end p-6 sm:p-9 lg:p-11">
                <motion.div initial="hidden" animate="show" variants={stagger}>
                  <motion.h1 variants={fadeUp} className="font-serif font-medium leading-[0.92] tracking-tight" style={{ color: C.cream, fontSize: "clamp(52px, 9vw, 132px)" }}>Sakura</motion.h1>
                  <motion.div variants={fadeUp} className="mt-1 flex items-baseline gap-4">
                    <span className="font-serif italic leading-none" style={{ color: C.gold, fontSize: "clamp(26px, 4.5vw, 64px)" }}>Sushi Bar</span>
                    <span className="hidden text-[11px] tracking-label sm:inline" style={{ color: C.pink }}>— Est. 2019</span>
                  </motion.div>
                  <motion.div variants={fadeUp} className="mt-6 flex flex-wrap items-center gap-5">
                    <p className="max-w-[360px] text-[13px] leading-relaxed" style={{ color: "rgba(255,250,245,0.78)" }}>
                      Handcrafted maki, signature rolls and a calm counter — Japanese food, made the way you like it.
                    </p>
                    <div className="flex items-center gap-3">
                      {[Instagram, Twitter].map((Icon, i) => (
                        <motion.a key={i} href="#" whileHover={{ y: -3, color: C.pink }} className="grid h-10 w-10 place-items-center rounded-full border" style={{ borderColor: "rgba(255,250,245,0.22)", color: "rgba(255,250,245,0.8)" }} aria-label="social link">
                          <Icon className="h-4 w-4" />
                        </motion.a>
                      ))}
                    </div>
                  </motion.div>
                </motion.div>
              </motion.div>
            </motion.div>

            {/* Right column */}
            <motion.div initial="hidden" animate="show" variants={stagger} className="grid grid-cols-2 gap-3 lg:col-span-4 lg:grid-cols-1 lg:grid-rows-4">
              {sidePanels.map((p) => <SidePanel key={p.label} panel={p} />)}
            </motion.div>
          </div>

          {/* trust strip */}
          <motion.div initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }} variants={stagger} className="mt-3 grid grid-cols-2 gap-3 rounded-[18px] p-4 sm:grid-cols-4 sm:p-5" style={{ background: C.bgSoft }}>
            {[
              { k: "Fresh fish", v: "Daily from Toyosu", c: C.green },
              { k: "Hand-pressed", v: "Shari at the counter", c: C.gold },
              { k: "Plant-based", v: "Vegan maki available", c: C.pink },
              { k: "Open evenings", v: "6 PM — late", c: C.green },
            ].map((t) => (
              <motion.div key={t.k} variants={fadeUp} className="flex items-center gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px]" style={{ background: `${t.c}22`, color: t.c }}>●</span>
                <div>
                  <p className="text-[13px] font-semibold">{t.k}</p>
                  <p className="text-[11px]" style={{ color: C.fgMuted }}>{t.v}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <KanjiMarquee />
      <PhilosophyBand />
      <MenuSection
        activeFilter={activeFilter} setActiveFilter={setActiveFilter}
        activeCategory={activeCategory} setActiveCategory={setActiveCategory}
        filteredDishes={filteredDishes} onSelectDish={setSelectedDishId}
      />
      <HiddenIngredientsMap />
      <FoodPlanner />
      <StatsSection />
      <FoodStories />
      <CultureSection />
      <ReservationCTA />
      <Footer />

      {/* floating UI */}
      <TrayButton />
      <TrayDrawer />
      <DishModal dish={selectedDish} onClose={() => setSelectedDishId(null)} />
      <ChatbotWidget />
    </main>
  );
}

/* ------------------------------------------------------------------ */
/*  Header                                                             */
/* ------------------------------------------------------------------ */
function Header({ menuOpen, setMenuOpen }: { menuOpen: boolean; setMenuOpen: (v: boolean) => void }) {
  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed left-3 right-3 top-3 z-50 sm:left-5 sm:top-5"
    >
      <div className="mx-auto flex max-w-[1480px] items-center justify-between rounded-[16px] px-3 py-2.5 backdrop-blur-xl sm:px-5" style={{ background: C.glass, border: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setMenuOpen(!menuOpen)} className="grid h-9 w-9 place-items-center rounded-[10px] transition-colors hover:bg-white/10" style={{ color: C.fg }} aria-label="Menu">
            {menuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
          <a href="#" className="flex items-center gap-2">
            <motion.span whileHover={{ rotate: -8, scale: 1.05 }} className="grid h-8 w-8 place-items-center rounded-full font-serif text-[15px] font-semibold text-white" style={{ background: `linear-gradient(145deg, ${C.pink}, #b71e3e)` }}>桜</motion.span>
            <span className="font-serif text-[19px] font-medium tracking-tight" style={{ color: C.fg }}>Sakura</span>
          </a>
        </div>

        <nav className="hidden items-center gap-7 md:flex">
          {["Menu", "Ingredients", "Planner", "Stories", "Culture"].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="group relative text-[11px] font-medium tracking-label transition-colors" style={{ color: C.fgMuted }}>
              <span className="transition-colors group-hover:text-[var(--sakura-fg)]">{item}</span>
              <motion.span className="absolute -bottom-1 left-0 h-[2px] w-0" style={{ background: C.pink }} whileHover={{ width: "100%" }} transition={{ duration: 0.3 }} />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <MagneticButton
            as="a"
            href="#reservation"
            className="flex items-center gap-2 rounded-[10px] px-4 py-2 text-[11px] font-semibold tracking-label text-white"
            style={{ background: C.pink, boxShadow: `0 8px 22px ${C.pink}40` }}
          >
            Book a Table
            <ArrowUpRight className="h-3.5 w-3.5" />
          </MagneticButton>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }} animate={{ opacity: 1, y: 0, height: "auto" }} exit={{ opacity: 0, y: -10, height: 0 }} transition={{ duration: 0.3 }}
            className="mx-auto mt-2 max-w-[1480px] overflow-hidden rounded-[14px] backdrop-blur-xl md:hidden" style={{ background: C.glass }}
          >
            {["Menu", "Ingredients", "Planner", "Stories", "Culture", "Reservation"].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setMenuOpen(false)} className="flex items-center justify-between border-b px-5 py-3.5 text-[13px] last:border-0" style={{ borderColor: C.border, color: C.fgSoft }}>
                {item}
                <ArrowUpRight className="h-3.5 w-3.5 opacity-50" />
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

/* ------------------------------------------------------------------ */
/*  Side panel with tilt                                               */
/* ------------------------------------------------------------------ */
function SidePanel({ panel }: { panel: (typeof sidePanels)[number] }) {
  const [hovered, setHovered] = useState(false);
  return (
    <motion.a
      href={panel.href}
      variants={panelReveal}
      whileHover="hover"
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      className="group relative block overflow-hidden rounded-[18px] lg:h-[220px] xl:h-[230px]"
      style={{ background: C.bgSoft }}
    >
      <motion.div variants={{ hover: { scale: 1.06 } }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className="absolute inset-0">
        <img src={panel.image} alt={panel.label} loading="lazy" className="h-full w-full object-cover" />
      </motion.div>
      <div className="pointer-events-none absolute inset-0 transition-opacity duration-500" style={{ background: "linear-gradient(180deg, rgba(20,28,36,0.05) 0%, rgba(20,28,36,0.15) 50%, rgba(20,28,36,0.82) 100%)", opacity: hovered ? 1 : 0.85 }} />
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
        <div>
          <span className="text-[10px] font-bold tracking-label" style={{ color: panel.accent }}>{panel.sub}</span>
          <h3 className="mt-1 font-serif text-[22px] font-medium text-white">{panel.label}</h3>
        </div>
        <motion.span variants={{ hover: { rotate: -45, scale: 1.1 } }} className="grid h-9 w-9 place-items-center rounded-full border border-white/30 text-white backdrop-blur-sm" style={{ background: "rgba(255,255,255,0.12)" }}>
          <ArrowUpRight className="h-4 w-4" />
        </motion.span>
      </div>
    </motion.a>
  );
}

/* ------------------------------------------------------------------ */
/*  Kanji marquee                                                      */
/* ------------------------------------------------------------------ */
function KanjiMarquee() {
  const items = ["桜", "寿司", "和食", "職人", "旬", "お任せ", "粋", "匠", "味", "心"];
  return (
    <section className="relative w-full overflow-hidden py-6" style={{ background: C.bg, borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }} aria-hidden>
      <div className="flex whitespace-nowrap">
        <motion.div className="flex shrink-0 items-center gap-12 pr-12" animate={{ x: ["0%", "-50%"] }} transition={{ duration: 30, repeat: Infinity, ease: "linear" }}>
          {[...items, ...items].map((k, i) => (
            <span key={i} className="flex items-center gap-12">
              <span className="font-serif text-[42px] font-light" style={{ color: "var(--sakura-fg-muted)", opacity: 0.4 }}>{k}</span>
              <span style={{ color: C.pink, fontSize: 10 }}>✦</span>
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Philosophy band                                                     */
/* ------------------------------------------------------------------ */
function PhilosophyBand() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  return (
    <section id="about" ref={ref} className="relative w-full px-4 py-24 sm:px-6 lg:px-8 lg:py-32" style={{ background: C.bg }}>
      <motion.div initial={{ opacity: 0, scale: 0.6, rotate: -12 }} whileInView={{ opacity: 1, scale: 1, rotate: -8 }} viewport={{ once: true }} transition={{ duration: 0.8, delay: 0.3 }} className="absolute right-8 top-16 hidden h-20 w-20 place-items-center rounded-[8px] lg:grid" style={{ background: C.pink, color: "white" }} aria-hidden>
        <span className="font-serif text-[32px] font-semibold">桜</span>
      </motion.div>

      <div className="mx-auto grid max-w-[1180px] grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="lg:col-span-5">
          <motion.span variants={fadeUp} className="text-[11px] font-bold tracking-label" style={{ color: C.green }}>✦ 私たちの哲学 · Our philosophy</motion.span>
          <motion.h2 variants={fadeUp} className="mt-4 font-serif text-[42px] font-medium leading-[1.05] tracking-tight sm:text-[54px]">
            Food, with the <span style={{ color: C.pink }}>details </span> that matter.
          </motion.h2>
        </motion.div>

        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="lg:col-span-7 lg:pt-2">
          <motion.p variants={fadeUp} className="text-[16px] leading-relaxed" style={{ color: C.fgSoft }}>
            We press every piece of shari by hand, slice fish to order, and keep the counter small on purpose. A quiet room, honest ingredients and a menu that respects every preference — including plant-based.
          </motion.p>
          <div className="mt-9 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {[
              { t: "Hand-pressed", jp: "手握り", d: "Shari warmed to body temperature, seasoned with our red-vinegar blend.", c: C.green },
              { t: "Sourced daily", jp: "毎日仕入", d: "Fish from Toyosu each morning, plus local seasonal greens.", c: C.gold },
              { t: "Made for you", jp: "おもてなし", d: "Vegan and plant-based maki, made with the same care.", c: C.pink },
            ].map((f, i) => (
              <motion.div key={f.t} variants={fadeUp}>
                <motion.span initial={{ scale: 0 }} animate={inView ? { scale: 1 } : {}} transition={{ delay: 0.3 + i * 0.15, type: "spring", stiffness: 200 }} className="grid h-11 w-11 place-items-center rounded-full text-[18px]" style={{ background: `${f.c}1a`, color: f.c }}>◆</motion.span>
                <h3 className="mt-3 font-serif text-[19px] font-semibold">{f.t}</h3>
                <p className="text-[11px]" style={{ color: f.c }}>{f.jp}</p>
                <p className="mt-1.5 text-[13px] leading-relaxed" style={{ color: C.fgMuted }}>{f.d}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Menu section with tabs + filters + tray                            */
/* ------------------------------------------------------------------ */
function MenuSection({
  activeFilter, setActiveFilter,
  activeCategory, setActiveCategory,
  filteredDishes, onSelectDish,
}: {
  activeFilter: DietTag | "all";
  setActiveFilter: (v: DietTag | "all") => void;
  activeCategory: "all" | Dish["category"];
  setActiveCategory: (v: "all" | Dish["category"]) => void;
  filteredDishes: typeof dishes;
  onSelectDish: (id: string) => void;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const add = useTray(selectAdd);

  return (
    <section id="menu" ref={ref} className="relative w-full px-4 py-24 sm:px-6 lg:px-8 lg:py-28" style={{ background: C.bg }}>
      <div className="mx-auto max-w-[1180px]">
        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <motion.span variants={fadeUp} className="text-[11px] font-bold tracking-label" style={{ color: C.gold }}>✦ カウンターから · Selected from the counter</motion.span>
            <motion.h2 variants={fadeUp} className="mt-3 font-serif text-[38px] font-medium leading-tight sm:text-[48px]">Signature pieces</motion.h2>
            <motion.p variants={fadeUp} className="mt-2 text-[13px]" style={{ color: C.fgMuted }}>Tap a dish to unfold its story · tap + to add to your tray.</motion.p>
          </div>
        </motion.div>

        {/* category tabs */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ delay: 0.25, duration: 0.6 }} className="mt-8 flex flex-wrap items-center gap-2">
          {categories.map((cat) => {
            const isActive = activeCategory === cat.key;
            return (
              <motion.button key={cat.key} onClick={() => setActiveCategory(cat.key)} whileHover={{ y: -2 }} whileTap={{ scale: 0.96 }} className="relative flex items-center gap-2 overflow-hidden rounded-full px-4 py-2 text-[12px] font-semibold tracking-label transition-colors" style={{ background: isActive ? C.fg : "transparent", color: isActive ? C.bg : C.fgSoft, border: `1px solid ${isActive ? C.fg : C.border}` }}>
                <span>{cat.label}</span>
                <span className="font-serif text-[11px] opacity-60" aria-hidden>{cat.jp}</span>
              </motion.button>
            );
          })}
        </motion.div>

        {/* dietary filters */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ delay: 0.35, duration: 0.6 }} className="mt-3 flex flex-wrap items-center gap-2">
          <span className="mr-2 text-[11px] tracking-label" style={{ color: C.fgMuted }}>フィルター · Diet</span>
          {dietFilters.map((f) => {
            const isActive = activeFilter === f.key;
            return (
              <motion.button key={f.key} onClick={() => setActiveFilter(f.key)} whileHover={{ y: -2 }} whileTap={{ scale: 0.96 }} className="flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] font-semibold tracking-label transition-colors" style={{ background: isActive ? C.pink : "transparent", color: isActive ? "white" : C.fgMuted, border: `1px solid ${isActive ? C.pink : C.border}` }}>
                {f.key === "vegan" && <Leaf className="h-3 w-3" />}
                {f.key === "vegetarian" && <Leaf className="h-3 w-3" />}
                {f.key === "jain-friendly" && <Sparkles className="h-3 w-3" />}
                {f.label}
              </motion.button>
            );
          })}
        </motion.div>

        {/* dish grid */}
        <motion.div layout className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filteredDishes.map((s) => (
              <DishCard key={s.id} dish={s} onSelect={onSelectDish} onAdd={() => add(s.id)} />
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredDishes.length === 0 && (
          <div className="mt-8 rounded-[14px] border border-dashed p-10 text-center text-[13px]" style={{ borderColor: C.border, color: C.fgMuted }}>
            No dishes match these filters yet. Try another preference.
          </div>
        )}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Dish card — 3D tilt + quick add                                    */
/* ------------------------------------------------------------------ */
function DishCard({
  dish, onSelect, onAdd,
}: {
  dish: typeof dishes[number];
  onSelect: (id: string) => void;
  onAdd: () => void;
}) {
  const [added, setAdded] = useState(false);
  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAdd();
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  };

  return (
    <motion.div
      layoutId={`dish-card-${dish.id}`}
      onClick={() => onSelect(dish.id)}
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: -20 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") onSelect(dish.id); }}
      className="group cursor-pointer overflow-hidden rounded-[18px]"
      style={{ background: C.card, border: `1px solid ${C.border}` }}
    >
      <TiltCard className="block" intensity={10}>
        <div className="relative aspect-[4/5] overflow-hidden">
          <motion.img layoutId={`dish-image-${dish.id}`} src={dish.image} alt={dish.name} loading="lazy" className="h-full w-full object-cover" />
          <div className="absolute inset-0 flex flex-col gap-1.5 p-3">
            <span className="w-fit rounded-full px-3 py-1 text-[10px] font-bold tracking-label text-white" style={{ background: dish.accent }}>{dish.category}</span>
            {dish.diet.filter((d) => d !== "omnivore").slice(0, 1).map((d) => (
              <span key={d} className="w-fit inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[9px] font-bold tracking-label uppercase text-white backdrop-blur-md" style={{ background: "rgba(20,107,69,0.85)" }}>
                <Leaf className="h-2.5 w-2.5" /> {d}
              </span>
            ))}
          </div>
          {/* quick add */}
          <motion.button
            onClick={handleAdd}
            whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
            className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full text-white backdrop-blur-md"
            style={{ background: added ? C.green : "rgba(20,28,36,0.7)" }}
            aria-label="Add to tray"
          >
            {added ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
          </motion.button>
        </div>
        <motion.div layoutId={`dish-title-${dish.id}`} className="flex items-center justify-between p-5">
          <div>
            <h3 className="font-serif text-[20px] font-medium">{dish.name}</h3>
            <p className="mt-0.5 font-serif text-[12px]" style={{ color: dish.accent }}>{dish.japanese}</p>
            <p className="mt-1 text-[12px]" style={{ color: C.fgMuted }}>{dish.tagline}</p>
          </div>
          <span className="font-serif text-[17px] font-semibold" style={{ color: C.gold }}>{dish.price}</span>
        </motion.div>
      </TiltCard>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Stats section with animated counters                              */
/* ------------------------------------------------------------------ */
function StatsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const stats = [
    { value: 9, suffix: "", label: "Counter seats", sub: "Two seatings nightly", accent: C.pink },
    { value: 10, suffix: " yrs", label: "Chef training", sub: "Before pressing a piece", accent: C.gold },
    { value: 48, suffix: " hrs", label: "Salmon aged", sub: "For depth and sweetness", accent: C.green },
    { value: 5, suffix: "", label: "Colours, flavours", sub: "The washoku rule", accent: C.pink },
  ];
  return (
    <section ref={ref} className="relative w-full px-4 py-20 sm:px-6 lg:px-8" style={{ background: C.bgSoft, borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}>
      <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="mx-auto grid max-w-[1180px] grid-cols-2 gap-6 lg:grid-cols-4">
        {stats.map((s) => (
          <motion.div key={s.label} variants={fadeUp} className="text-center sm:text-left">
            <div className="font-serif text-[44px] font-semibold leading-none sm:text-[56px]" style={{ color: s.accent }}>
              <AnimatedCounter to={s.value} suffix={s.suffix} duration={1.6} />
            </div>
            <p className="mt-3 text-[13px] font-semibold">{s.label}</p>
            <p className="text-[11px]" style={{ color: C.fgMuted }}>{s.sub}</p>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Food stories                                                       */
/* ------------------------------------------------------------------ */
function FoodStories() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <section id="stories" ref={ref} className="relative w-full px-4 py-24 sm:px-6 lg:px-8 lg:py-28" style={{ background: C.bg }}>
      <div className="mx-auto max-w-[1180px]">
        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="mb-12 max-w-[620px]">
          <motion.span variants={fadeUp} className="text-[11px] font-bold tracking-label" style={{ color: C.pink }}>✦ 料理の物語 · Food stories</motion.span>
          <motion.h2 variants={fadeUp} className="mt-3 font-serif text-[40px] font-medium leading-[1.08] tracking-tight sm:text-[52px]">Every dish carries a story older than the plate.</motion.h2>
        </motion.div>

        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {foodStories.map((story, i) => (
            <motion.article key={story.kanji} variants={fadeUp} whileHover={{ y: -6 }} transition={{ duration: 0.4 }} className="group relative flex flex-col overflow-hidden rounded-[20px]" style={{ background: C.card, border: `1px solid ${C.border}` }}>
              <div className="relative h-[220px] overflow-hidden sm:h-[200px]">
                <motion.img src={story.image} alt={story.title} loading="lazy" className="h-full w-full object-cover" whileHover={{ scale: 1.06 }} transition={{ duration: 0.6 }} />
                <motion.span initial={{ scale: 0, rotate: -12 }} whileInView={{ scale: 1, rotate: -6 }} viewport={{ once: true }} transition={{ delay: 0.4 + i * 0.15, type: "spring", stiffness: 200 }} className="absolute right-4 top-4 grid h-14 w-14 place-items-center rounded-[10px] font-serif text-[24px] font-semibold text-white shadow-lg" style={{ background: story.accent }} aria-hidden>{story.kanji}</motion.span>
              </div>
              <div className="flex flex-1 flex-col p-6">
                <span className="text-[10px] font-bold tracking-label" style={{ color: story.accent }}>{story.romaji}</span>
                <h3 className="mt-2 font-serif text-[22px] font-semibold leading-snug">{story.title}</h3>
                <p className="mt-3 text-[14px] leading-relaxed" style={{ color: C.fgSoft }}>{story.excerpt}</p>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Culture section                                                    */
/* ------------------------------------------------------------------ */
function CultureSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <section id="culture" ref={ref} className="relative w-full overflow-hidden px-4 py-24 sm:px-6 lg:px-8 lg:py-28" style={{ background: C.bg }}>
      <motion.div initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 0.06, y: 0 }} viewport={{ once: true }} transition={{ duration: 1 }} className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 select-none font-serif text-[clamp(200px,38vw,520px)] font-bold leading-none" style={{ color: C.fg }} aria-hidden>心</motion.div>

      <div className="relative mx-auto max-w-[1180px]">
        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="mb-12">
          <motion.span variants={fadeUp} className="text-[11px] font-bold tracking-label" style={{ color: C.green }}>✦ 日本の文化 · A note on culture</motion.span>
          <motion.h2 variants={fadeUp} className="mt-3 font-serif text-[38px] font-medium leading-tight sm:text-[48px]">Words worth knowing before you sit down.</motion.h2>
        </motion.div>

        <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {cultureItems.map((it, i) => (
            <motion.div key={it.romaji} variants={panelReveal} whileHover={{ y: -6 }} transition={{ duration: 0.4 }} className="group relative overflow-hidden rounded-[18px] p-7" style={{ background: C.card, borderTop: `3px solid ${it.accent}` }}>
              <span className="font-serif text-[44px] font-medium" style={{ color: it.accent }}>{it.kanji}</span>
              <p className="mt-1 text-[11px] tracking-label" style={{ color: C.fgMuted }}>{it.romaji}</p>
              <h3 className="mt-4 font-serif text-[22px] font-semibold">{it.title}</h3>
              <p className="mt-3 text-[14px] leading-relaxed" style={{ color: C.fgSoft }}>{it.body}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Reservation CTA                                                    */
/* ------------------------------------------------------------------ */
function ReservationCTA() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <section id="reservation" ref={ref} className="relative w-full overflow-hidden px-4 py-24 sm:px-6 lg:px-8 lg:py-28" style={{ background: C.bg }}>
      <div className="pointer-events-none absolute -left-32 top-1/2 h-[420px] w-[420px] -translate-y-1/2 rounded-full blur-[120px]" style={{ background: "var(--sakura-glow-pink)" }} />
      <div className="pointer-events-none absolute -right-32 top-1/3 h-[380px] w-[380px] rounded-full blur-[120px]" style={{ background: "var(--sakura-glow-green)" }} />

      <motion.div initial="hidden" animate={inView ? "show" : "hidden"} variants={stagger} className="relative mx-auto max-w-[1180px] overflow-hidden rounded-[24px]" style={{ background: `linear-gradient(110deg, ${C.pink2}, ${C.cream})` }}>
        <div className="grid grid-cols-1 lg:grid-cols-12">
          <motion.div variants={fadeUp} className="p-9 sm:p-12 lg:col-span-7 lg:p-14">
            <span className="text-[11px] font-bold tracking-label" style={{ color: C.pink }}>✦ 予約 · Reserve a seat</span>
            <h2 className="mt-4 font-serif text-[40px] font-medium leading-[1.05] tracking-tight sm:text-[54px]" style={{ color: C.ink }}>
              A quiet counter,<br /><span style={{ color: C.pink }}>nine seats</span> each evening.
            </h2>
            <p className="mt-5 max-w-[420px] text-[14px] leading-relaxed" style={{ color: "#5a6470" }}>Two seatings nightly, at 6:30 PM and 8:45 PM. Bookings open a week ahead. Walk-ins welcome at the bar.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <MagneticButton as="a" href="#" className="inline-flex items-center gap-2 rounded-[12px] px-6 py-3.5 text-[12px] font-semibold tracking-label text-white" style={{ background: C.pink }}>
                Book a table <ArrowUpRight className="h-4 w-4" />
              </MagneticButton>
              <MagneticButton as="a" href="#" className="inline-flex items-center gap-2 rounded-[12px] px-6 py-3.5 text-[12px] font-semibold tracking-label" style={{ border: `1px solid ${C.border}`, color: C.ink }}>
                Call us
              </MagneticButton>
            </div>
          </motion.div>
          <motion.div variants={panelReveal} className="relative min-h-[280px] overflow-hidden lg:col-span-5">
            <img src="/images/restaurant-interior.png" alt="Inside Sakura Sushi Bar" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(255,250,245,0.35) 0%, rgba(255,250,245,0) 40%)" }} />
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Footer                                                             */
/* ------------------------------------------------------------------ */
function Footer() {
  return (
    <footer className="relative w-full px-4 py-14 sm:px-6 lg:px-8" style={{ background: C.bgSoft, color: C.fg }}>
      <div className="mx-auto max-w-[1180px]">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full font-serif text-[16px] font-semibold text-white" style={{ background: `linear-gradient(145deg, ${C.pink}, #b71e3e)` }}>桜</span>
              <span className="font-serif text-[22px] font-medium">Sakura Sushi Bar</span>
            </div>
            <p className="mt-4 max-w-[300px] text-[13px] leading-relaxed" style={{ color: C.fgMuted }}>A small Japanese counter in Indiranagar. Handcrafted maki, quiet evenings and food made the way you like it.</p>
            <div className="mt-5 flex items-center gap-3">
              {[Instagram, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="grid h-9 w-9 place-items-center rounded-full border transition-colors hover:text-[var(--sakura-pink)]" style={{ borderColor: C.border, color: C.fgMuted }} aria-label="social link">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-[11px] font-bold tracking-label" style={{ color: C.gold }}>ご来店 · Visit</h4>
            <p className="mt-4 text-[13px] leading-relaxed" style={{ color: C.fgMuted }}>100 Feet Road, Indiranagar<br />Bengaluru 560038<br /><span style={{ color: C.pink }}>Open 6 PM — late</span></p>
          </div>
          <div>
            <h4 className="text-[11px] font-bold tracking-label" style={{ color: C.gold }}>探す · Explore</h4>
            <div className="mt-4 flex flex-col gap-2.5">
              {["Menu", "Ingredients", "Planner", "Stories", "Culture"].map((l) => (
                <a key={l} href={`#${l.toLowerCase()}`} className="text-[13px] transition-colors hover:text-[var(--sakura-fg)]" style={{ color: C.fgMuted }}>{l}</a>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t pt-6 text-[11px] sm:flex-row" style={{ borderColor: C.border, color: C.fgMuted }}>
          <span>© {new Date().getFullYear()} Sakura Sushi Bar · Crafted with care</span>
          <span className="tracking-label">桜 · すし · ば</span>
        </div>
      </div>
    </footer>
  );
}
