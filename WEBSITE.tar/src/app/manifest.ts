import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Sakura Sushi Bar",
    short_name: "Sakura",
    description:
      "Handcrafted Japanese cuisine — maki, nigiri, ramen and plant-based dishes. Made the way you like it.",
    start_url: "/",
    display: "standalone",
    background_color: "#1f2933",
    theme_color: "#ed2851",
    icons: [
      {
        src: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
