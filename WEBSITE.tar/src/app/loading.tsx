/**
 * Route-level loading state — shown while the page bundle loads.
 * Uses pure CSS animation (no framer-motion) because loading.tsx runs on
 * the server and cannot use client-only motion components.
 */
export default function Loading() {
  return (
    <div
      className="grid min-h-screen place-items-center"
      style={{ background: "#1f2933" }}
    >
      <div className="flex flex-col items-center gap-5">
        <span
          className="grid h-14 w-14 place-items-center rounded-full font-serif text-[26px] font-semibold text-white"
          style={{
            background: "linear-gradient(145deg, #ed2851, #b71e3e)",
            animation: "sakura-pulse 1.6s ease-in-out infinite",
          }}
        >
          桜
        </span>
        <div className="flex gap-1.5">
          {[0, 1, 2].map((d) => (
            <span
              key={d}
              className="h-1.5 w-1.5 rounded-full"
              style={{
                background: "#f3b341",
                animation: `sakura-bounce 1s ease-in-out ${d * 0.15}s infinite`,
              }}
            />
          ))}
        </div>
      </div>
      <style>{`
        @keyframes sakura-pulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(0.94); opacity: 0.85; }
        }
        @keyframes sakura-bounce {
          0%, 100% { transform: translateY(0); opacity: 0.3; }
          50% { transform: translateY(-4px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
