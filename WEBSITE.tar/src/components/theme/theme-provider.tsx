"use client";

import { useCallback, useEffect, useSyncExternalStore } from "react";
import { createContext, useContext } from "react";

type Theme = "light" | "dark";

interface ThemeContextValue {
  theme: Theme;
  toggle: () => void;
  setTheme: (t: Theme) => void;
}

/**
 * SSR-safe theme provider using useSyncExternalStore.
 *
 * The inline script in layout.tsx sets the `light`/`dark` class on <html>
 * before hydration so visuals are correct on first paint. This provider reads
 * that class via useSyncExternalStore — the server snapshot is always "dark"
 * (matching the initial React state), so there is no hydration mismatch.
 */
const subscribeTheme = (callback: () => void) => {
  const observer = new MutationObserver(callback);
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class"],
  });
  return () => observer.disconnect();
};

const getTheme = (): Theme =>
  document.documentElement.classList.contains("light") ? "light" : "dark";

const getServerTheme = (): Theme => "dark";

function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = useSyncExternalStore(subscribeTheme, getTheme, getServerTheme);

  const apply = useCallback((t: Theme) => {
    const root = document.documentElement;
    root.classList.toggle("light", t === "light");
    root.classList.toggle("dark", t === "dark");
    try {
      localStorage.setItem("sakura-theme", t);
    } catch {
      /* ignore */
    }
  }, []);

  const toggle = useCallback(() => {
    apply(theme === "dark" ? "light" : "dark");
  }, [theme, apply]);

  // follow system preference only if the user hasn't explicitly chosen
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: light)");
    const handler = (e: MediaQueryListEvent) => {
      let stored: string | null = null;
      try {
        stored = localStorage.getItem("sakura-theme");
      } catch {
        /* ignore */
      }
      if (!stored) apply(e.matches ? "light" : "dark");
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [apply]);

  return (
    <ThemeContext.Provider value={{ theme, toggle, setTheme: apply }}>
      {children}
    </ThemeContext.Provider>
  );
}

export { ThemeProvider };

const ThemeContext = createContext<ThemeContextValue>({
  theme: "dark",
  toggle: () => {},
  setTheme: () => {},
});
export function useTheme() {
  return useContext(ThemeContext);
}
