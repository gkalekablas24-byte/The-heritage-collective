"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Leaf,
  Sparkles,
  ChefHat,
  GlassWater,
  BookOpen,
  Plus,
  Check,
  AlertTriangle,
} from "lucide-react";
import type { Dish } from "@/lib/dishes";
import { C } from "@/lib/dishes";
import { useTray, selectAdd } from "@/lib/tray-store";

/**
 * Dish modal — expands a dish into its full story, ingredients,
 * chef's note, pairing and an add-to-tray action.
 */
export function DishModal({
  dish,
  onClose,
}: {
  dish: Dish | null;
  onClose: () => void;
}) {
  const add = useTray(selectAdd);
  const [justAdded, setJustAdded] = useState(false);

  // close on Escape + lock scroll.
  // `justAdded` resets naturally because the modal is keyed by dish.id in the parent AnimatePresence.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    if (dish) {
      document.body.style.overflow = "hidden";
    }
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [dish, onClose]);

  const handleAdd = () => {
    if (!dish) return;
    add(dish.id);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1600);
  };

  return (
    <AnimatePresence>
      {dish && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-end justify-center p-0 sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          <motion.div
            className="absolute inset-0"
            style={{ background: C.overlay, backdropFilter: "blur(8px)" }}
            onClick={onClose}
          />

          <motion.div
            layoutId={`dish-card-${dish.id}`}
            className="relative z-10 flex max-h-[92vh] w-full max-w-[920px] flex-col overflow-hidden rounded-t-[28px] sm:rounded-[24px]"
            style={{ background: C.bgSoft, color: C.fg }}
            initial={{ y: 60, scale: 0.96 }}
            animate={{ y: 0, scale: 1 }}
            exit={{ y: 60, scale: 0.96, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
          >
            {/* image header */}
            <div className="relative h-[240px] shrink-0 overflow-hidden sm:h-[300px]">
              <motion.img
                layoutId={`dish-image-${dish.id}`}
                src={dish.image}
                alt={dish.name}
                className="h-full w-full object-cover"
              />
              <div
                className="pointer-events-none absolute inset-0"
                style={{
                  background: `linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.2) 50%, var(--sakura-bg-soft) 100%)`,
                }}
              />

              <button
                onClick={onClose}
                className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full text-white backdrop-blur-md"
                style={{ background: "rgba(10,16,22,0.55)" }}
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="absolute left-5 top-4 flex items-center gap-3">
                <span
                  className="rounded-full px-3 py-1 text-[10px] font-bold tracking-[0.2em] uppercase text-white"
                  style={{ background: dish.accent }}
                >
                  {dish.category}
                </span>
                <span
                  className="vertical-rl font-serif text-[18px]"
                  style={{ color: "rgba(255,255,255,0.85)" }}
                  aria-hidden
                >
                  {dish.japanese}
                </span>
              </div>

              <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
                <motion.h2
                  layoutId={`dish-title-${dish.id}`}
                  className="font-serif text-[36px] font-medium leading-tight tracking-tight sm:text-[46px]"
                >
                  {dish.name}
                </motion.h2>
                <p className="mt-1 text-[13px]" style={{ color: C.fgMuted }}>{dish.romaji}</p>
              </div>
            </div>

            {/* scrollable body */}
            <div className="flex-1 overflow-y-auto px-5 pb-8 pt-5 sm:px-8">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap gap-2">
                  {dish.diet.map((d) => (
                    <span
                      key={d}
                      className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10px] font-semibold tracking-[0.14em] uppercase"
                      style={{
                        borderColor: C.border,
                        color: C.fg,
                        background: "transparent",
                      }}
                    >
                      {d === "vegan" ? (
                        <Leaf className="h-3 w-3" style={{ color: C.green }} />
                      ) : d === "vegetarian" ? (
                        <Leaf className="h-3 w-3" style={{ color: C.gold }} />
                      ) : d === "jain-friendly" ? (
                        <Sparkles className="h-3 w-3" style={{ color: C.pink }} />
                      ) : null}
                      {d}
                    </span>
                  ))}
                </div>
                <span className="font-serif text-[22px] font-semibold" style={{ color: C.gold }}>
                  {dish.price}
                </span>
              </div>

              <p
                className="mt-5 text-[12px] font-bold tracking-[0.2em] uppercase"
                style={{ color: dish.accent }}
              >
                {dish.tagline}
              </p>
              <p className="mt-2 text-[15px] leading-relaxed" style={{ color: C.fgSoft }}>
                {dish.description}
              </p>

              <SectionLabel icon={<ChefHat className="h-3.5 w-3.5" />} text="Ingredients" />
              <div className="mt-3 flex flex-wrap gap-2">
                {dish.ingredients.map((ing, idx) => (
                  <motion.span
                    key={ing}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 + idx * 0.05 }}
                    className="rounded-[10px] px-3 py-2 text-[12px]"
                    style={{
                      background: C.cardHi,
                      border: `1px solid ${C.border}`,
                      color: C.fgSoft,
                    }}
                  >
                    {ing}
                  </motion.span>
                ))}
              </div>

              {/* Hidden ingredients watchlist */}
              {dish.hiddenIngredients && dish.hiddenIngredients.length > 0 && (
                <>
                  <SectionLabel
                    icon={<AlertTriangle className="h-3.5 w-3.5" />}
                    text="What to confirm elsewhere"
                  />
                  <div className="mt-3 space-y-2">
                    {dish.hiddenIngredients.map((h, idx) => (
                      <motion.div
                        key={h.name}
                        initial={{ opacity: 0, x: 16 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + idx * 0.06 }}
                        className="flex items-start gap-3 rounded-[12px] p-3"
                        style={{
                          background: h.risk === "high" ? `${C.pink}10` : C.cardHi,
                          border: `1px solid ${h.risk === "high" ? `${C.pink}33` : C.border}`,
                        }}
                      >
                        <span
                          className="mt-0.5 shrink-0 rounded-full px-2 py-0.5 text-[9px] font-bold tracking-label uppercase"
                          style={{
                            background: h.risk === "high" ? `${C.pink}22` : `${C.gold}22`,
                            color: h.risk === "high" ? C.pink : C.gold,
                          }}
                        >
                          {h.risk}
                        </span>
                        <div>
                          <p className="text-[13px] font-semibold">{h.name}</p>
                          <p className="mt-0.5 text-[12px] leading-relaxed" style={{ color: C.fgSoft }}>
                            {h.note}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <p className="mt-2 text-[11px]" style={{ color: C.fgMuted }}>
                    At Sakura, we make this dish without these. The watchlist is for eating the
                    same dish elsewhere in Japan.
                  </p>
                </>
              )}

              <SectionLabel icon={<BookOpen className="h-3.5 w-3.5" />} text="The story" />
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.25 }}
                className="mt-3 font-serif text-[16px] italic leading-relaxed"
                style={{ color: C.fgSoft }}
              >
                {dish.story}
              </motion.p>

              <div
                className="mt-6 rounded-[14px] p-5"
                style={{
                  background: `${C.pink}12`,
                  border: `1px solid ${C.pink}33`,
                }}
              >
                <div className="flex items-center gap-2">
                  <ChefHat className="h-4 w-4" style={{ color: C.pink }} />
                  <span
                    className="text-[11px] font-bold tracking-[0.2em] uppercase"
                    style={{ color: C.pink }}
                  >
                    Chef&apos;s note
                  </span>
                </div>
                <p className="mt-2 text-[14px] leading-relaxed" style={{ color: C.fgSoft }}>
                  {dish.chefNote}
                </p>
              </div>

              <div className="mt-5 flex items-center gap-3">
                <GlassWater className="h-4 w-4" style={{ color: C.gold }} />
                <span className="text-[12px]" style={{ color: C.fgMuted }}>Pairs with</span>
                <span className="text-[14px] font-medium">{dish.pairing}</span>
              </div>

              {/* actions */}
              <div className="mt-7 flex gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAdd}
                  className="flex flex-1 items-center justify-center gap-2 rounded-[12px] py-3.5 text-[12px] font-semibold tracking-[0.18em] uppercase text-white"
                  style={{ background: justAdded ? C.green : C.pink }}
                >
                  {justAdded ? (
                    <>
                      <Check className="h-4 w-4" /> Added to tray
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" /> Add to tray
                    </>
                  )}
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onClose}
                  className="rounded-[12px] px-6 py-3.5 text-[12px] font-semibold tracking-[0.18em] uppercase"
                  style={{ border: `1px solid ${C.border}`, color: C.fg }}
                >
                  Close · 閉じる
                </motion.button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function SectionLabel({
  icon,
  text,
}: {
  icon: React.ReactNode;
  text: string;
}) {
  return (
    <div className="mt-7 flex items-center gap-2">
      <span style={{ color: C.gold }}>{icon}</span>
      <span
        className="text-[11px] font-bold tracking-[0.2em] uppercase"
        style={{ color: C.gold }}
      >
        {text}
      </span>
      <div className="ml-3 h-px flex-1" style={{ background: C.border }} />
    </div>
  );
}
