"use client";

import { useMemo, useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Calculator, Users, Wallet, Leaf, Sparkles, RefreshCw, Check, ArrowRight } from "lucide-react";
import { C, dishes, parsePrice, formatPrice, type DietTag } from "@/lib/dishes";
import { useTray } from "@/lib/tray-store";

/* ------------------------------------------------------------------ */
/*  Planner — honest dietary meal planner with a budget                */
/* ------------------------------------------------------------------ */

export function FoodPlanner() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  const [diet, setDiet] = useState<DietTag | "all">("vegan");
  const [budget, setBudget] = useState<number>(3000);
  const [party, setParty] = useState<number>(2);
  const [planned, setPlanned] = useState(false);

  // compute the recommendation
  const { plan, total, perHead, withinBudget } = useMemo(() => {
    const perHeadBudget = budget / Math.max(1, party);
    // filter by diet
    let pool = dishes.filter((d) => diet === "all" || d.diet.includes(diet));
    // sort by price ascending for an honest low-first plan
    pool = [...pool].sort((a, b) => parsePrice(a.price) - parsePrice(b.price));

    // greedy: build a balanced set — 1 course-style item, a couple appetizers, a noodle/rice, a dessert
    const plan: typeof dishes = [];
    const push = (d: (typeof dishes)[number] | undefined) => d && plan.push(d);

    // one "main" (ramen/noodle/rice/course)
    const mains = pool.filter((d) =>
      ["Ramen", "Noodle", "Rice", "Course"].includes(d.category),
    );
    // appetizers
    const apps = pool.filter((d) => d.category === "Appetizer");
    // maki/nigiri
    const sushi = pool.filter((d) => ["Maki", "Nigiri"].includes(d.category));
    // dessert
    const dessert = pool.filter((d) => d.category === "Dessert");

    // pick one of each per person (cap distinct dishes to keep it readable)
    push(mains[0]);
    if (party > 1) push(mains[1] ?? mains[0]);
    push(apps[0]);
    if (party > 2) push(apps[1] ?? apps[0]);
    push(sushi[0]);
    if (party > 1) push(sushi[1] ?? sushi[0]);
    push(dessert[0]);

    // scale quantities so each guest gets one of each chosen dish
    const scaled = plan.map((d) => ({ dish: d, qty: party }));
    const total = scaled.reduce((a, x) => a + parsePrice(x.dish.price) * x.qty, 0);
    const perHead = total / Math.max(1, party);

    return {
      plan: scaled,
      total,
      perHead,
      withinBudget: total <= budget,
    };
  }, [diet, budget, party]);

  function addToTrayFromPlan() {
    const store = useTray.getState();
    plan.forEach(({ dish, qty }) => {
      for (let i = 0; i < qty; i++) store.add(dish.id);
    });
    setPlanned(true);
    setTimeout(() => setPlanned(false), 2000);
  }

  const dietOptions: { key: DietTag | "all"; label: string; jp: string }[] = [
    { key: "vegetarian", label: "Vegetarian", jp: "菜食" },
    { key: "vegan", label: "Vegan", jp: "精進" },
    { key: "jain-friendly", label: "Jain", jp: "ジャイナ" },
  ];

  return (
    <section
      id="planner"
      ref={ref}
      className="relative w-full px-4 py-24 sm:px-6 lg:px-8 lg:py-28"
      style={{ background: C.bgSoft, borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}
    >
      <div className="mx-auto max-w-[1180px]">
        <motion.div
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }}
          className="mb-10 max-w-[680px]"
        >
          <motion.span
            variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            className="text-[11px] font-bold tracking-label"
            style={{ color: C.gold }}
          >
            ✦ 食事計画 · An honest food planner
          </motion.span>
          <motion.h2
            variants={{ hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] } } }}
            className="mt-3 font-serif text-[38px] font-medium leading-tight sm:text-[48px]"
          >
            Plan a meal that fits your
            <span style={{ color: C.gold }}> diet </span>
            and your
            <span style={{ color: C.pink }}> budget.</span>
          </motion.h2>
          <motion.p
            variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            className="mt-3 text-[14px] leading-relaxed"
            style={{ color: C.fgMuted }}
          >
            No upsell. Pick your diet and what you can spend — we&apos;ll suggest an honest
            set per person, with the hidden ingredients called out. You can send the whole
            plan to your tray.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* ============ Controls ============ */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-5"
          >
            <div
              className="rounded-[20px] p-6"
              style={{ background: C.card, border: `1px solid ${C.border}` }}
            >
              {/* diet */}
              <div className="flex items-center gap-2">
                <Leaf className="h-4 w-4" style={{ color: C.green }} />
                <span className="text-[11px] font-bold tracking-label" style={{ color: C.green }}>
                  Dietary preference
                </span>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {dietOptions.map((d) => {
                  const active = diet === d.key;
                  return (
                    <motion.button
                      key={d.key}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setDiet(d.key)}
                      className="rounded-[12px] px-3 py-3 text-center transition-colors"
                      style={{
                        background: active ? C.green : C.bgElev,
                        color: active ? "white" : C.fgSoft,
                        border: `1px solid ${active ? C.green : C.border}`,
                      }}
                    >
                      <span className="block text-[12px] font-semibold">{d.label}</span>
                      <span className="font-serif text-[10px] opacity-70">{d.jp}</span>
                    </motion.button>
                  );
                })}
              </div>

              {/* party size */}
              <div className="mt-6 flex items-center gap-2">
                <Users className="h-4 w-4" style={{ color: C.gold }} />
                <span className="text-[11px] font-bold tracking-label" style={{ color: C.gold }}>
                  Party size
                </span>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setParty((p) => Math.max(1, p - 1))}
                  className="grid h-10 w-10 place-items-center rounded-full text-[18px] font-bold"
                  style={{ background: C.bgElev, color: C.fg, border: `1px solid ${C.border}` }}
                >
                  −
                </motion.button>
                <motion.span
                  key={party}
                  initial={{ scale: 1.3 }}
                  animate={{ scale: 1 }}
                  className="min-w-[50px] text-center font-serif text-[30px] font-semibold"
                >
                  {party}
                </motion.span>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setParty((p) => Math.min(12, p + 1))}
                  className="grid h-10 w-10 place-items-center rounded-full text-[18px] font-bold"
                  style={{ background: C.bgElev, color: C.fg, border: `1px solid ${C.border}` }}
                >
                  +
                </motion.button>
                <span className="ml-1 text-[12px]" style={{ color: C.fgMuted }}>
                  {party === 1 ? "guest" : "guests"}
                </span>
              </div>

              {/* budget */}
              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wallet className="h-4 w-4" style={{ color: C.pink }} />
                  <span className="text-[11px] font-bold tracking-label" style={{ color: C.pink }}>
                    Budget
                  </span>
                </div>
                <span className="font-serif text-[18px] font-semibold" style={{ color: C.pink }}>
                  {formatPrice(budget)}
                </span>
              </div>
              <input
                type="range"
                min={800}
                max={12000}
                step={200}
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="mt-3 w-full"
                style={{ accentColor: C.pink }}
              />
              <div className="mt-1 flex justify-between text-[10px]" style={{ color: C.fgMuted }}>
                <span>¥800</span>
                <span>¥12,000</span>
              </div>
            </div>
          </motion.div>

          {/* ============ Results ============ */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="lg:col-span-7"
          >
            <div
              className="rounded-[20px] p-6"
              style={{ background: C.card, border: `1px solid ${C.border}` }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calculator className="h-4 w-4" style={{ color: C.gold }} />
                  <h3 className="font-serif text-[20px] font-semibold">Your suggested plan</h3>
                </div>
                <span
                  className="rounded-full px-3 py-1 text-[10px] font-bold tracking-label"
                  style={{
                    background: withinBudget ? `${C.green}1a` : `${C.pink}1a`,
                    color: withinBudget ? C.green : C.pink,
                  }}
                >
                  {withinBudget ? "Within budget" : "Over budget"}
                </span>
              </div>

              {/* list */}
              <div className="mt-4 space-y-2">
                <AnimatePresence mode="popLayout">
                  {plan.map(({ dish, qty }) => (
                    <motion.div
                      key={dish.id}
                      layout
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -12 }}
                      transition={{ duration: 0.3 }}
                      className="flex items-center gap-3 rounded-[12px] p-2.5"
                      style={{ background: C.bgElev, border: `1px solid ${C.border}` }}
                    >
                      <div
                        className="h-12 w-12 shrink-0 overflow-hidden rounded-[8px]"
                        style={{ background: C.bg }}
                      >
                        <img src={dish.image} alt={dish.name} loading="lazy" className="h-full w-full object-cover" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="truncate text-[13px] font-semibold">{dish.name}</p>
                          <span className="font-serif text-[10px]" style={{ color: dish.accent }}>{dish.japanese}</span>
                        </div>
                        <p className="truncate text-[11px]" style={{ color: C.fgMuted }}>{dish.tagline}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[11px]" style={{ color: C.fgMuted }}>×{qty}</p>
                        <p className="font-serif text-[13px] font-semibold" style={{ color: C.gold }}>
                          {formatPrice(parsePrice(dish.price) * qty)}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* totals */}
              <div className="mt-5 grid grid-cols-3 gap-3">
                <div className="rounded-[12px] p-3" style={{ background: C.bgElev }}>
                  <p className="text-[10px] tracking-label" style={{ color: C.fgMuted }}>PER HEAD</p>
                  <p className="mt-1 font-serif text-[18px] font-semibold" style={{ color: C.gold }}>
                    {formatPrice(Math.round(perHead))}
                  </p>
                </div>
                <div className="rounded-[12px] p-3" style={{ background: C.bgElev }}>
                  <p className="text-[10px] tracking-label" style={{ color: C.fgMuted }}>TOTAL</p>
                  <p className="mt-1 font-serif text-[18px] font-semibold" style={{ color: C.pink }}>
                    {formatPrice(total)}
                  </p>
                </div>
                <div className="rounded-[12px] p-3" style={{ background: C.bgElev }}>
                  <p className="text-[10px] tracking-label" style={{ color: C.fgMuted }}>BUDGET</p>
                  <p className="mt-1 font-serif text-[18px] font-semibold">
                    {formatPrice(budget)}
                  </p>
                </div>
              </div>

              {/* hidden ingredient honest note */}
              <div
                className="mt-4 flex items-start gap-2 rounded-[12px] p-3"
                style={{ background: `${C.pink}10`, border: `1px solid ${C.pink}33` }}
              >
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0" style={{ color: C.pink }} />
                <p className="text-[12px] leading-relaxed" style={{ color: C.fgSoft }}>
                  <strong>Honestly:</strong> every dish above is made plant-based at Sakura (kombu
                  &amp; shiitake dashi, no bonito, no shared seafood oil). At other restaurants
                  in Japan, confirm dashi and oil for the same dishes — tap any item for the
                  hidden-ingredient list.
                </p>
              </div>

              {/* actions */}
              <div className="mt-5 flex flex-wrap gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={addToTrayFromPlan}
                  className="flex flex-1 items-center justify-center gap-2 rounded-[12px] py-3 text-[12px] font-semibold tracking-label text-white"
                  style={{ background: planned ? C.green : C.pink }}
                >
                  {planned ? (
                    <><Check className="h-4 w-4" /> Added to tray</>
                  ) : (
                    <><ArrowRight className="h-4 w-4" /> Send plan to tray</>
                  )}
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setDiet("vegan");
                    setBudget(3000);
                    setParty(2);
                  }}
                  className="flex items-center justify-center gap-2 rounded-[12px] px-5 py-3 text-[12px] font-semibold tracking-label"
                  style={{ border: `1px solid ${C.border}`, color: C.fg }}
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Reset
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
