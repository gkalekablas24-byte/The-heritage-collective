"use client";

import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { MapPin, AlertTriangle, CheckCircle2, X } from "lucide-react";
import { C, dishes } from "@/lib/dishes";

/* ------------------------------------------------------------------ */
/*  Map locations — sourcing spots in Indiranagar, Bengaluru           */
/* ------------------------------------------------------------------ */
interface MapSpot {
  id: string;
  label: string;
  jp: string;
  type: "sourcing" | "restaurant" | "market";
  x: number; // % position on the map
  y: number;
  detail: string;
  accent: string;
}

const spots: MapSpot[] = [
  {
    id: "sakura",
    label: "Sakura Sushi Bar",
    jp: "桜寿司",
    type: "restaurant",
    x: 52,
    y: 48,
    detail: "Our counter — nine seats, two seatings. Plant-based dishes made without bonito or fish dashi.",
    accent: C.pink,
  },
  {
    id: "tofu-house",
    label: "Indiranagar Tofu House",
    jp: "豆腐屋",
    type: "sourcing",
    x: 30,
    y: 30,
    detail: "Supplies our silken tofu each morning, still warm. The base for hiyayakko and agedashi.",
    accent: C.green,
  },
  {
    id: "organic-market",
    label: "Weekend Organic Market",
    jp: "有機市",
    type: "market",
    x: 72,
    y: 28,
    detail: "Saturday sourcing: shiso, lotus root, japanese eggplant, and seasonal greens.",
    accent: C.green,
  },
  {
    id: "kombu-importer",
    label: "Kombu & Shiitake Importer",
    jp: "昆布・椎茸",
    type: "sourcing",
    x: 22,
    y: 66,
    detail: "Hokkaido kombu and dried shiitake — the backbone of our plant-based dashi.",
    accent: C.gold,
  },
  {
    id: "rice-mill",
    label: "Short-Grain Rice Mill",
    jp: "米屋",
    type: "sourcing",
    x: 78,
    y: 64,
    detail: "Koshihikari-style short-grain rice, milled to order. The grain for shari.",
    accent: C.gold,
  },
  {
    id: "matcha-shop",
    label: "Matcha & Kinako Shop",
    jp: "抹茶",
    type: "sourcing",
    x: 60,
    y: 76,
    detail: "Ceremonial matcha and roasted soybean flour for our mochi.",
    accent: C.green,
  },
];

/* ------------------------------------------------------------------ */
/*  Hidden-ingredient watchlist (drawn from dishes)                    */
/* ------------------------------------------------------------------ */
const watchlist = [
  { name: "Bonito stock (katsuo-dashi)", risk: "high" as const, where: "dashi, miso soup, ramen broth, mentsuyu, tempura sauce", ask: "「かつおなし、昆布だしで」Katsuo nashi, kombu-dashi de" },
  { name: "Bonito flakes (katsuobushi)", risk: "high" as const, where: "okonomiyaki, takoyaki, agedashi, hiyayakko garnish", ask: "「かつおぶし抜きで」Katsuobushi nuki de" },
  { name: "Mirin (sweet cooking wine)", risk: "medium" as const, where: "teriyaki, miso glaze, rice seasoning", ask: "「みりんなしで」Mirin nashi de" },
  { name: "Shared frying oil", risk: "medium" as const, where: "tempura, karaage, katsu", ask: "「えびと同じ油ですか？」Ebi to onaji abura desu ka?" },
  { name: "Egg in noodles / batter", risk: "medium" as const, where: "ramen noodles, tempura batter", ask: "「卵なしで」Tamago nashi de" },
];

export function HiddenIngredientsMap() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [activeSpot, setActiveSpot] = useState<MapSpot | null>(null);

  // collect hidden ingredients from all dishes
  const allHidden = dishes.flatMap((d) =>
    (d.hiddenIngredients ?? []).map((h) => ({ ...h, dish: d.name })),
  );

  return (
    <section
      id="ingredients"
      ref={ref}
      className="relative w-full px-4 py-24 sm:px-6 lg:px-8 lg:py-28"
      style={{ background: C.bg }}
    >
      <div className="mx-auto max-w-[1180px]">
        {/* heading */}
        <motion.div
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          variants={{
            hidden: {},
            show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
          }}
          className="mb-10 max-w-[680px]"
        >
          <motion.span
            variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            className="text-[11px] font-bold tracking-label"
            style={{ color: C.pink }}
          >
            ✦ 隠し成分 · Hidden ingredients & the city map
          </motion.span>
          <motion.h2
            variants={{ hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] } } }}
            className="mt-3 font-serif text-[38px] font-medium leading-tight sm:text-[48px]"
          >
            Vegetables don&apos;t always mean
            <span style={{ color: C.pink }}> vegetarian.</span>
          </motion.h2>
          <motion.p
            variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            className="mt-3 text-[14px] leading-relaxed"
            style={{ color: C.fgMuted }}
          >
            The hardest part of eating plant-based in Japan isn&apos;t finding vegetables —
            it&apos;s the stock, the sauce, the oil. Here is an honest map of what to watch
            for, where our ingredients come from, and the phrases that help.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* ============ Map ============ */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-7"
          >
            <div
              className="relative overflow-hidden rounded-[20px] p-5"
              style={{
                background: C.bgSoft,
                border: `1px solid ${C.border}`,
                aspectRatio: "4 / 3",
              }}
            >
              {/* Map label */}
              <div className="absolute left-5 top-5 z-10">
                <p className="text-[10px] font-bold tracking-label" style={{ color: C.gold }}>
                  インディラナガル · Indiranagar
                </p>
                <p className="font-serif text-[18px] font-semibold">Our sourcing map</p>
              </div>

              {/* legend */}
              <div className="absolute right-5 top-5 z-10 flex gap-3">
                {[
                  { c: C.pink, l: "Sakura" },
                  { c: C.green, l: "Plant sourcing" },
                  { c: C.gold, l: "Pantry" },
                ].map((g) => (
                  <div key={g.l} className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: g.c }} />
                    <span className="text-[9px] tracking-label" style={{ color: C.fgMuted }}>
                      {g.l}
                    </span>
                  </div>
                ))}
              </div>

              {/* Stylised map grid */}
              <svg
                viewBox="0 0 400 300"
                className="absolute inset-0 h-full w-full"
                preserveAspectRatio="xMidYMid slice"
                aria-hidden
              >
                {/* roads */}
                <g stroke="var(--sakura-border)" strokeWidth="1" opacity="0.5">
                  <line x1="0" y1="80" x2="400" y2="80" />
                  <line x1="0" y1="160" x2="400" y2="160" />
                  <line x1="0" y1="230" x2="400" y2="230" />
                  <line x1="100" y1="0" x2="100" y2="300" />
                  <line x1="220" y1="0" x2="220" y2="300" />
                  <line x1="320" y1="0" x2="320" y2="300" />
                </g>
                {/* diagonal main road */}
                <line
                  x1="0" y1="280" x2="400" y2="40"
                  stroke="var(--sakura-gold)"
                  strokeWidth="2.5"
                  opacity="0.35"
                />
                {/* blocks */}
                <g fill="var(--sakura-bg-elev)" opacity="0.4">
                  <rect x="110" y="90" width="100" height="60" rx="6" />
                  <rect x="230" y="90" width="80" height="60" rx="6" />
                  <rect x="110" y="170" width="100" height="50" rx="6" />
                  <rect x="230" y="170" width="80" height="50" rx="6" />
                  <rect x="20" y="170" width="70" height="50" rx="6" />
                  <rect x="330" y="170" width="60" height="50" rx="6" />
                </g>
              </svg>

              {/* pins */}
              {spots.map((s, i) => (
                <motion.button
                  key={s.id}
                  onClick={() => setActiveSpot(s)}
                  initial={{ opacity: 0, scale: 0, y: -10 }}
                  animate={inView ? { opacity: 1, scale: 1, y: 0 } : {}}
                  transition={{ delay: 0.4 + i * 0.1, type: "spring", stiffness: 260, damping: 18 }}
                  whileHover={{ scale: 1.15, zIndex: 20 }}
                  className="absolute z-10 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${s.x}%`, top: `${s.y}%` }}
                  aria-label={s.label}
                >
                  <span
                    className="grid h-7 w-7 place-items-center rounded-full border-2 text-white shadow-lg"
                    style={{
                      background: s.accent,
                      borderColor: C.bgSoft,
                    }}
                  >
                    <MapPin className="h-3.5 w-3.5" />
                  </span>
                  {/* pulse ring for Sakura */}
                  {s.id === "sakura" && (
                    <motion.span
                      className="absolute inset-0 rounded-full"
                      style={{ background: s.accent }}
                      animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut" }}
                    />
                  )}
                </motion.button>
              ))}

              {/* spot tooltip */}
              <AnimatePresence>
                {activeSpot && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute bottom-5 left-5 right-5 z-20 rounded-[14px] p-4 backdrop-blur-md"
                    style={{
                      background: "var(--sakura-glass)",
                      border: `1px solid ${C.border}`,
                    }}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className="h-2.5 w-2.5 rounded-full"
                            style={{ background: activeSpot.accent }}
                          />
                          <p className="font-serif text-[16px] font-semibold">{activeSpot.label}</p>
                          <span className="font-serif text-[12px]" style={{ color: activeSpot.accent }}>
                            {activeSpot.jp}
                          </span>
                        </div>
                        <p className="mt-1.5 text-[12px] leading-relaxed" style={{ color: C.fgSoft }}>
                          {activeSpot.detail}
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveSpot(null)}
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-full"
                        style={{ color: C.fgMuted }}
                        aria-label="Close"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

          {/* ============ Watchlist ============ */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-5"
          >
            <div
              className="rounded-[20px] p-5"
              style={{ background: C.bgSoft, border: `1px solid ${C.border}` }}
            >
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" style={{ color: C.pink }} />
                <h3 className="text-[11px] font-bold tracking-label" style={{ color: C.pink }}>
                  The hidden watchlist
                </h3>
              </div>
              <p className="mt-2 text-[12px]" style={{ color: C.fgMuted }}>
                Five ingredients that hide in &quot;vegetable&quot; dishes across Japan. Tap a dish
                on the menu to see which apply to it.
              </p>

              <div className="mt-4 space-y-2.5">
                {watchlist.map((w, i) => (
                  <motion.div
                    key={w.name}
                    initial={{ opacity: 0, x: 20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.4 + i * 0.08 }}
                    className="rounded-[12px] p-3"
                    style={{ background: C.bgElev, border: `1px solid ${C.border}` }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-[13px] font-semibold">{w.name}</p>
                      <span
                        className="rounded-full px-2 py-0.5 text-[9px] font-bold tracking-label uppercase"
                        style={{
                          background: w.risk === "high" ? `${C.pink}22` : `${C.gold}22`,
                          color: w.risk === "high" ? C.pink : C.gold,
                        }}
                      >
                        {w.risk} risk
                      </span>
                    </div>
                    <p className="mt-1 text-[11px]" style={{ color: C.fgMuted }}>
                      Found in: {w.where}
                    </p>
                    <p className="mt-1.5 font-serif text-[11px] italic" style={{ color: C.green }}>
                      Ask: {w.ask}
                    </p>
                  </motion.div>
                ))}
              </div>

              <div
                className="mt-4 flex items-start gap-2 rounded-[12px] p-3"
                style={{ background: `${C.green}12`, border: `1px solid ${C.green}33` }}
              >
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" style={{ color: C.green }} />
                <p className="text-[12px] leading-relaxed" style={{ color: C.fgSoft }}>
                  <strong>At Sakura</strong> — every plant-based dish is made with kombu &amp;
                  shiitake dashi, no bonito, no shared oil with seafood. Ask at the counter
                  and we&apos;ll walk you through it.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
