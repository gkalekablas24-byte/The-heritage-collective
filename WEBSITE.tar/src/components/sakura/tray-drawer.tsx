"use client";

import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowUpRight } from "lucide-react";
import { useTray, formatPrice, parsePrice, selectLines, selectIsOpen, selectClose, selectAdd, selectDec, selectRemove, selectOpen } from "@/lib/tray-store";
import { dishes, C } from "@/lib/dishes";

/** Compute count + total from lines (stable, derived in-component) */
function useCounts() {
  const lines = useTray(selectLines);
  return useMemo(() => {
    const arr = Object.values(lines);
    const count = arr.reduce((a, l) => a + l.qty, 0);
    const total = arr.reduce((a, l) => {
      const dish = dishes.find((d) => d.id === l.id);
      return a + (dish ? parsePrice(dish.price) * l.qty : 0);
    }, 0);
    return { count, total };
  }, [lines]);
}

/** Floating tray button — shows the running count badge */
export function TrayButton() {
  const { count } = useCounts();
  const open = useTray(selectOpen);
  return (
    <motion.button
      onClick={open}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 220, damping: 18 }}
      whileHover={{ scale: 1.06 }}
      whileTap={{ scale: 0.93 }}
      className="fixed bottom-5 right-5 z-[80] grid h-14 w-14 place-items-center rounded-full shadow-2xl"
      style={{
        background: C.pink,
        boxShadow: `0 12px 30px ${C.pink}55`,
      }}
      aria-label="Open your tray"
    >
      <ShoppingBag className="h-5 w-5 text-white" />
      <AnimatePresence>
        {count > 0 && (
          <motion.span
            key={count}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            transition={{ type: "spring", stiffness: 500, damping: 24 }}
            className="absolute -right-1 -top-1 grid h-6 min-w-[24px] place-items-center rounded-full px-1.5 text-[11px] font-bold text-white"
            style={{ background: C.ink }}
          >
            {count}
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

/** Slide-out tray drawer */
export function TrayDrawer() {
  const lines = useTray(selectLines);
  const isOpen = useTray(selectIsOpen);
  const close = useTray(selectClose);
  const add = useTray(selectAdd);
  const dec = useTray(selectDec);
  const remove = useTray(selectRemove);
  const { total, count } = useCounts();

  const lineItems = Object.values(lines)
    .map((l) => {
      const dish = dishes.find((d) => d.id === l.id);
      return dish ? { dish, qty: l.qty } : null;
    })
    .filter(Boolean) as { dish: (typeof dishes)[number]; qty: number }[];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[90]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* backdrop */}
          <motion.div
            className="absolute inset-0"
            style={{ background: C.overlay, backdropFilter: "blur(6px)" }}
            onClick={close}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* panel */}
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 38 }}
            className="absolute right-0 top-0 flex h-full w-full max-w-[440px] flex-col"
            style={{ background: C.bgSoft, color: C.fg }}
          >
            {/* header */}
            <div
              className="flex items-center justify-between px-6 py-5"
              style={{ borderBottom: `1px solid ${C.border}` }}
            >
              <div>
                <p className="text-[11px] font-bold tracking-label" style={{ color: C.gold }}>
                  お盆 · Your tray
                </p>
                <h3 className="font-serif text-[22px] font-medium">Selections</h3>
              </div>
              <button
                onClick={close}
                className="grid h-9 w-9 place-items-center rounded-full border"
                style={{ borderColor: C.border }}
                aria-label="Close tray"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {lineItems.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="grid h-16 w-16 place-items-center rounded-full"
                    style={{ background: `${C.gold}1a`, color: C.gold }}
                  >
                    <ShoppingBag className="h-7 w-7" />
                  </motion.div>
                  <p className="mt-4 font-serif text-[20px] font-medium">Your tray is empty</p>
                  <p className="mt-1 text-[13px]" style={{ color: C.fgMuted }}>
                    Add dishes from the menu to begin building your order.
                  </p>
                </div>
              ) : (
                <ul className="space-y-3">
                  <AnimatePresence initial={false}>
                    {lineItems.map(({ dish, qty }) => (
                      <motion.li
                        key={dish.id}
                        layout
                        initial={{ opacity: 0, x: 40 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 40, height: 0 }}
                        transition={{ type: "spring", stiffness: 320, damping: 32 }}
                        className="flex gap-3 rounded-[14px] p-3"
                        style={{ background: C.card, border: `1px solid ${C.border}` }}
                      >
                        <div
                          className="h-16 w-16 shrink-0 overflow-hidden rounded-[10px]"
                          style={{ background: C.bgElev }}
                        >
                          <img
                            src={dish.image}
                            alt={dish.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <h4 className="truncate font-serif text-[15px] font-semibold">
                                {dish.name}
                              </h4>
                              <p className="font-serif text-[11px]" style={{ color: dish.accent }}>
                                {dish.japanese}
                              </p>
                            </div>
                            <button
                              onClick={() => remove(dish.id)}
                              className="grid h-7 w-7 place-items-center rounded-full text-[var(--sakura-fg-muted)] transition-colors hover:text-[var(--sakura-pink)]"
                              aria-label="Remove"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          <div className="mt-2 flex items-center justify-between">
                            <div className="flex items-center gap-1 rounded-full p-1" style={{ background: C.bgElev }}>
                              <button
                                onClick={() => dec(dish.id)}
                                className="grid h-6 w-6 place-items-center rounded-full"
                                style={{ color: C.fg }}
                                aria-label="Decrease"
                              >
                                <Minus className="h-3 w-3" />
                              </button>
                              <span className="min-w-[20px] text-center text-[12px] font-semibold">
                                {qty}
                              </span>
                              <button
                                onClick={() => add(dish.id)}
                                className="grid h-6 w-6 place-items-center rounded-full"
                                style={{ color: C.fg }}
                                aria-label="Increase"
                              >
                                <Plus className="h-3 w-3" />
                              </button>
                            </div>
                            <span className="font-serif text-[14px] font-semibold" style={{ color: C.gold }}>
                              {formatPrice(parsePrice(dish.price) * qty)}
                            </span>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              )}
            </div>

            {/* footer */}
            {lineItems.length > 0 && (
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="px-6 py-5"
                style={{ borderTop: `1px solid ${C.border}`, background: C.bgElev }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[12px] tracking-label" style={{ color: C.fgMuted }}>
                    {count} {count === 1 ? "item" : "items"}
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-[11px] tracking-label" style={{ color: C.fgMuted }}>合計</span>
                    <span className="font-serif text-[26px] font-semibold" style={{ color: C.gold }}>
                      {formatPrice(total)}
                    </span>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-[12px] py-3.5 text-[12px] font-semibold tracking-label text-white"
                  style={{ background: C.pink }}
                >
                  Reserve with this tray
                  <ArrowUpRight className="h-4 w-4" />
                </motion.button>
                <p className="mt-2 text-center text-[10px]" style={{ color: C.fgMuted }}>
                  Prototype · no live booking connected
                </p>
              </motion.div>
            )}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
