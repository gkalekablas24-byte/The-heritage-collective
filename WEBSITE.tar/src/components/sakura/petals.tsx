"use client";

import { useMemo } from "react";
import { motion } from "framer-motion";

/**
 * Sakura petals — continuously falling cherry blossom petals.
 * Purely decorative, pointer-events disabled, fixed behind content.
 */
export function SakuraPetals({ count = 18 }: { count?: number }) {
  // generate petals once
  const petals = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => {
        const left = Math.random() * 100; // vw
        const delay = Math.random() * 12; // s
        const duration = 11 + Math.random() * 10; // s
        const size = 8 + Math.random() * 10; // px
        const drift = (Math.random() - 0.5) * 160; // px horizontal drift
        const rotateEnd = (Math.random() - 0.5) * 540; // deg
        const hue = Math.random() > 0.6 ? "255, 240, 243" : "255, 250, 245"; // pink2 / cream
        return { i, left, delay, duration, size, drift, rotateEnd, hue };
      }),
    [count],
  );

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-[5] overflow-hidden"
    >
      {petals.map((p) => (
        <motion.span
          key={p.i}
          initial={{ y: -40, x: 0, opacity: 0, rotate: 0 }}
          animate={{
            y: ["-40px", "110vh"],
            x: [0, p.drift, p.drift * 0.6],
            opacity: [0, 0.85, 0.85, 0],
            rotate: [0, p.rotateEnd],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{
            position: "absolute",
            left: `${p.left}%`,
            top: 0,
            width: p.size,
            height: p.size,
            // sakura petal shape using border-radius
            borderRadius: "100% 0 100% 0",
            background: `rgba(${p.hue}, 0.9)`,
            boxShadow: `0 0 6px rgba(${p.hue}, 0.4)`,
          }}
        />
      ))}
    </div>
  );
}
