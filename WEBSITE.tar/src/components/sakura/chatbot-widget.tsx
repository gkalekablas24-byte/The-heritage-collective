"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { C } from "@/lib/dishes";

interface Msg {
  role: "user" | "assistant";
  content: string;
}

const SUGGESTIONS = [
  "What vegan dishes do you have?",
  "I'm Jain — what should I avoid?",
  "Is your ramen broth really plant-based?",
  "How do I say 'no fish' in Japanese?",
];

export function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Konnichiwa! I'm Sakura, your host. I can help with the menu, dietary needs (vegan / vegetarian / Jain), and hidden ingredients in Japanese food. What would you like to know?",
    },
  ]);
  const sessionIdRef = useRef<string>("");
  if (!sessionIdRef.current) {
    sessionIdRef.current = `s${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  }
  const sessionId = sessionIdRef.current;
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // autoscroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open]);

  // focus input on open
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 300);
  }, [open]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content }]);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, message: content }),
      });
      const data = await res.json();
      const reply =
        data?.reply ||
        "Sorry, I couldn't reach the kitchen just now. Try again?";
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
    } catch {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content:
            "My apologies — the connection dropped. Please try again in a moment.",
        },
      ]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {/* Floating button */}
      <motion.button
        onClick={() => setOpen((v) => !v)}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.2, type: "spring", stiffness: 220, damping: 18 }}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.93 }}
        className="fixed bottom-5 left-5 z-[80] flex h-14 items-center gap-2 rounded-full pl-4 pr-5 text-white shadow-2xl"
        style={{
          background: `linear-gradient(135deg, ${C.green}, #0d5536)`,
          boxShadow: `0 12px 30px ${C.green}55`,
        }}
        aria-label="Ask Sakura"
      >
        <MessageCircle className="h-5 w-5" />
        <span className="text-[13px] font-semibold tracking-label hidden sm:inline">
          Ask Sakura
        </span>
        <motion.span
          animate={{ scale: [1, 1.3, 1], opacity: [0.7, 0, 0.7] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full"
          style={{ background: C.gold }}
        />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed bottom-24 left-5 z-[85] flex h-[520px] w-[min(380px,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-[20px] shadow-2xl"
            style={{
              background: C.bgSoft,
              border: `1px solid ${C.border}`,
              color: C.fg,
            }}
          >
            {/* header */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: `1px solid ${C.border}`, background: C.bgElev }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="grid h-9 w-9 place-items-center rounded-full text-white"
                  style={{ background: `linear-gradient(145deg, ${C.pink}, #b71e3e)` }}
                >
                  桜
                </span>
                <div>
                  <p className="font-serif text-[15px] font-semibold">Sakura</p>
                  <p className="flex items-center gap-1 text-[10px]" style={{ color: C.green }}>
                    <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: C.green }} />
                    Online · your host
                  </p>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-full"
                style={{ color: C.fgMuted }}
                aria-label="Close chat"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* messages */}
            <div
              ref={scrollRef}
              className="flex-1 space-y-3 overflow-y-auto px-4 py-4"
            >
              {messages.map((m, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
                >
                  <div
                    className="max-w-[80%] whitespace-pre-wrap rounded-[14px] px-3.5 py-2.5 text-[13px] leading-relaxed"
                    style={
                      m.role === "user"
                        ? { background: C.pink, color: "white" }
                        : { background: C.cardHi, color: C.fg, border: `1px solid ${C.border}` }
                    }
                  >
                    {m.content}
                  </div>
                </motion.div>
              ))}
              {busy && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-start"
                >
                  <div
                    className="flex gap-1 rounded-[14px] px-4 py-3"
                    style={{ background: C.cardHi, border: `1px solid ${C.border}` }}
                  >
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        className="h-1.5 w-1.5 rounded-full"
                        style={{ background: C.fgMuted }}
                        animate={{ opacity: [0.3, 1, 0.3], y: [0, -2, 0] }}
                        transition={{ duration: 1, repeat: Infinity, delay: d * 0.15 }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* suggestions (only at start) */}
              {messages.length <= 1 && !busy && (
                <div className="space-y-2 pt-2">
                  <p className="flex items-center gap-1 text-[10px] tracking-label" style={{ color: C.fgMuted }}>
                    <Sparkles className="h-3 w-3" style={{ color: C.gold }} /> Try asking
                  </p>
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      onClick={() => send(s)}
                      className="block w-full rounded-[10px] px-3 py-2 text-left text-[12px] transition-colors"
                      style={{
                        border: `1px solid ${C.border}`,
                        color: C.fgSoft,
                        background: "transparent",
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 px-3 py-3"
              style={{ borderTop: `1px solid ${C.border}`, background: C.bgElev }}
            >
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about dishes, ingredients…"
                className="flex-1 rounded-full px-4 py-2.5 text-[13px] outline-none"
                style={{ background: C.bg, color: C.fg, border: `1px solid ${C.border}` }}
                disabled={busy}
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.92 }}
                type="submit"
                disabled={busy || !input.trim()}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-white disabled:opacity-40"
                style={{ background: C.pink }}
                aria-label="Send"
              >
                <Send className="h-4 w-4" />
              </motion.button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
